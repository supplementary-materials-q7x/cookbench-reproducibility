# ai_connector.py
import requests
import json
import openai
import base64
import os
import io
from local_detector import LocalDetector
from semantic_map_tool import SemanticMapTool

class AIConnector:
    def __init__(self, config):
        self.config = config
        self.mode = config.get('execution_mode', 'hpc')
        print(f"[*] AI Connector initialized in '{self.mode}' mode.")

        if self.mode == 'local_api':
            self.api_providers = self.config.get('api_providers', {})
            self.api_assignments = self.config.get('api_model_assignments', {})
            self.clients = {}
            local_tool_config = self.config.get('local_tool_config', {})
            self.use_yolo = local_tool_config.get('use_yolo_detector', False)
            if self.use_yolo:
                yolo_path = local_tool_config.get('yolo_world_path')
                self.local_detector = LocalDetector(yolo_path) if yolo_path else None
            else:
                self.local_detector = None
            map_path = self.config.get('semantic_map_path')
            self.map_tool = SemanticMapTool(map_path) if map_path and os.path.exists(map_path) else None
            
            # 加载物品和工具信息
            self.products_data = self._load_json_data(self.config.get('products_json_path', './data/Products_en.json'))
            self.tools_data = self._load_json_data(self.config.get('tools_json_path', './data/tool_en.json'))
            self.action2api_data = self._load_json_data(self.config.get('action2api_json_path', './data/action2API_en.json'))
            print(f"[*] Loaded {len(self.products_data)} products, {len(self.tools_data)} tools, and {len(self.action2api_data)} action mappings.")
        elif self.mode == 'hpc':
            self.service_urls = self.config.get('hpc_config', {}).get('service_urls', {})
    
    def _load_json_data(self, file_path):
        """加载JSON数据文件"""
        try:
            if os.path.exists(file_path):
                with open(file_path, 'r', encoding='utf-8') as f:
                    return json.load(f)
            else:
                print(f"[!] Warning: File not found: {file_path}")
                return []
        except Exception as e:
            print(f"[!] Error loading JSON file {file_path}: {e}")
            return []

    def _get_api_client(self, provider_name):
        """获取或创建API客户端"""
        if provider_name in self.clients:
            return self.clients[provider_name]
            
        provider_config = self.api_providers[provider_name]
        provider_type = provider_config['provider_type']
        
        if provider_type == 'openai':
            client = openai.OpenAI(
                base_url=provider_config['base_url'],
                api_key=provider_config['api_key']
            )
        elif provider_type == 'anthropic':
            # TODO: 添加Anthropic客户端支持
            raise NotImplementedError("Anthropic client not implemented yet")
        else:
            raise ValueError(f"Unknown provider type: {provider_type}")
            
        self.clients[provider_name] = client
        return client

    def recognize_intent(self, user_instruction, all_dishes):
        """智能识别用户意图，匹配到具体的菜品。"""
        dish_names = [dish['dish_name'] for dish in all_dishes]

        if self.mode == 'local_api':
            provider_name = self.api_assignments['intent_recognition']
            client = self._get_api_client(provider_name)
            model_name = self.api_providers[provider_name]['model_name']
            
            prompt = f"""
            A user wants to cook something. Their instruction is: "{user_instruction}".
            From the following list of available dishes, which one is the best match?
            Dish List: {json.dumps(dish_names, indent=2)}
            Your task is to return a single JSON object with one key, "matched_dish_name", containing the exact name from the list.
            
            Note: In the cooking game, when the mouse cursor hovers over any object in the scene, a tooltip will appear showing what the object is. This feature helps identify objects before interacting with them.
            """
            print(f"[*] Calling {model_name} for intent recognition...")
            try:
                response = client.chat.completions.create(
                    model=model_name,
                    response_format={"type": "json_object"},
                    messages=[{"role": "user", "content": prompt}]
                )
                response_str = response.choices[0].message.content
                if "```json" in response_str:
                    response_str = response_str.split("```json\n")[1].split("```")[0]
                
                matched_name = json.loads(response_str).get("matched_dish_name")
                for dish in all_dishes:
                    if dish['dish_name'] == matched_name:
                        return dish
                return None
            except Exception as e:
                print(f"[!] API Intent Recognition failed: {e}")
                return None
        
        elif self.mode == 'hpc':
            # ... HPC意图识别逻辑 ...
            pass

    def get_ai_decision(self, pil_image, action_details, main_goal, memory_context, human_feedback):
        """统一的决策获取接口。"""
        if self.mode == 'local_api':
            return self._get_decision_from_api_tools(pil_image, action_details, main_goal, memory_context, human_feedback)
        elif self.mode == 'hpc':
            return self._get_decision_from_hpc(pil_image, action_details, main_goal, memory_context, human_feedback)

    # def _get_vlm_description(self, pil_image, detected_objects):
    #     """调用VLM获取场景的定性描述，可以选择性地融合检测信息。"""
    #     print("[*] Stage 1b: Calling VLM for grounded scene understanding...")
    #     buffered = io.BytesIO(); pil_image.save(buffered, format="PNG")
    #     img_base64 = base64.b64encode(buffered.getvalue()).decode('utf-8')
        
    #     provider_name = self.api_assignments['scene_understanding']
    #     client = self._get_api_client(provider_name)
    #     model_name = self.api_providers[provider_name]['model_name']
        
    #     prompt = f"""
    #     Analyze the provided image of a kitchen game scene, using the pre-computed object detection results as a reference.
    #     Your goal is to provide a rich, natural language description of the scene that synthesizes both the image and the data.

    #     **Reference Detection Data (from YOLO-World, if available):**
    #     {json.dumps(detected_objects, indent=2) if detected_objects else "Not used or no objects detected."}

    #     **Your Task:**
    #     Based on the image and the reference data, describe the scene. Mention the state of key objects and their spatial relationships. Pay attention to what the agent is holding.
    #     Example: "The agent is holding a knife. On the counter, I can see a cutting board, which the detector located at coordinates around [x,y,w,h]. To its left is a piece of raw pork."
    #     """
    #     try:
    #         response = client.chat.completions.create(
    #             model=model_name,
    #             messages=[{"role": "user", "content": [{"type": "text", "text": prompt}, {"type": "image_url", "image_url": {"url": f"data:image/png;base64,{img_base64}"}}]}]
    #         )
    #         print("感知内容：", response.choices[0].message.content)
    #         return response.choices[0].message.content
    #     except Exception as e:
    #         print(f"[!] API Scene Understanding failed: {e}")
    #         return "Error understanding scene."
    

    # 【关键修改】函数签名增加了 objects_info 和 semantic_map_info 参数
    def get_vlm_decision(self, pil_image, memory_context, available_actions, objects_info, semantic_map_info):
        """
        【知识增强版】直接调用VLM，根据图像、上下文及静态知识进行端到端决策。
        """
        print("[*] Calling Knowledge-Enhanced VLM as End-to-End Planner...")

        # 1. 准备图像数据 (建议加入图像缩放)
        buffered = io.BytesIO()
        pil_image.save(buffered, format="PNG")
        img_base64 = base64.b64encode(buffered.getvalue()).decode('utf-8')
        
        # 2. 获取VLM客户端和模型信息
        provider_name = self.api_assignments['scene_understanding']
        client = self._get_api_client(provider_name)
        model_name = self.api_providers[provider_name]['model_name']

        # 3. 构建一个融入了“先验知识”的终极Prompt
        vlm_prompt = f"""
        You are an expert AI agent playing a cooking game. Your task is to analyze the screenshot, your mission context, and provided static knowledge to decide the single best action to take next.

        **1. STATIC KNOWLEDGE - 3D SEMANTIC MAP:**
        This map describes the general layout of the kitchen. Use it to understand where major areas and appliances are.
        {json.dumps(semantic_map_info, indent=2, ensure_ascii=False)}

        **2. STATIC KNOWLEDGE - RELEVANT OBJECT DETAILS:**
        This provides details about items potentially relevant to your current task, including their properties and typical locations (`relative_position`).
        {json.dumps(objects_info, indent=2, ensure_ascii=False)}

        **3. MISSION CONTEXT (Your memory and current goals):**
        {memory_context}

        **4. AVAILABLE ACTIONS (The ONLY functions you can call):**
        {json.dumps(available_actions, indent=2)}

        **YOUR TASK:**
        1.  **Analyze the image**: This is your primary source of truth about the current world state.
        2.  **Synthesize with Knowledge**: Cross-reference what you see with the Semantic Map and Object Details. For example, if your task is to get a lemon, use the object details to know its `relative_position` and the map to plan your navigation.
        3.  **Recommend the Next Action**: Choose the single most logical function to call from the "AVAILABLE ACTIONS" list. Use the knowledge to fill in parameters accurately.

        **OUTPUT FORMAT:**
        Your response MUST be a single JSON object with "action", "parameters", and "reasoning".
        Example:
        {{
        "action": "navigate_to_object",
        "parameters": {{
            "object_name": "Lemon"
        }},
        "reasoning": "My current task is to get the Lemon. According to the object details, its relative_position is on the vegetable rack. I will navigate there first."
        }}
        """

        try:
            response = client.chat.completions.create(
                model=model_name,
                response_format={"type": "json_object"},
                messages=[
                    {
                        "role": "user",
                        "content": [
                            {"type": "text", "text": vlm_prompt},
                            {"type": "image_url", "image_url": {"url": f"data:image/png;base64,{img_base64}"}}
                        ]
                    }
                ]
            )
            response_str = response.choices[0].message.content
            if "```json" in response_str:
                response_str = response_str.split("```json\n")[1].split("```")[0]
            
            decision = json.loads(response_str)
            print(f"[*] VLM Planner Decision: {decision.get('action')}, Reason: {decision.get('reasoning')}")
            return decision

        except Exception as e:
            print(f"[!] VLM Planner failed: {e}")
            return {"action": "wait", "parameters": {"duration": 2}, "reasoning": "VLM planning failed, waiting and retrying."}
        
    def _get_yolo_detections(self, pil_image, ingredients):
        """调用本地YOLO检测器。"""
        if self.local_detector and ingredients:
            print(f"[*] Stage 1a: Calling local detector to find: {ingredients}")
            return self.local_detector.find_objects(pil_image, ingredients)
        return []

    def _get_semantic_map_knowledge(self, main_goal):
        """查询语义地图工具。"""
        if not self.map_tool:
            return {}
        dish_name = main_goal.get('dish_name', '')
        if not dish_name: return {}
        
        print(f"[*] Stage 1c: Querying Semantic Map Tool for '{dish_name}' context...")
        query_results = self.map_tool.query_object_relationships(dish_name)
        return query_results[0] if query_results else {}
        
    def _extract_potential_objects(self, scene_description, detected_objects):
        """从场景描述和检测结果中提取可能的物品名称。"""
        potential_objects = set()
        
        # 从场景描述中提取可能的物品名称
        if scene_description:
            # 先尝试使用LLM提取物品名称
            extracted_objects = self._extract_objects_with_llm(scene_description)
            if extracted_objects:
                potential_objects.update(extracted_objects)
            
            # 如果LLM提取失败或结果不足，使用简单的关键词匹配
            # 获取所有产品和工具的名称
            all_product_names = [p.get("item_name", "").lower() for p in self.products_data]
            all_tool_names = [t.get("tool_name", "").lower() for t in self.tools_data]
            
            # 在场景描述中查找匹配的名称
            scene_lower = scene_description.lower()
            for name in all_product_names + all_tool_names:
                if name and name in scene_lower:
                    potential_objects.add(name)
        
        # 从检测结果中提取物品名称
        if detected_objects:
            for obj in detected_objects:
                if "class" in obj:
                    potential_objects.add(obj["class"])
                    
        # 限制返回的物品数量，避免过多查询
        return list(potential_objects)[:10]  # 最多返回10个物品
    
    def _extract_task_related_objects(self, task_description, recipe):
        """提取与当前任务相关的物品名称。"""
        potential_objects = set()
        
        # 从任务描述中提取物品名称
        if task_description:
            # 使用LLM提取物品名称
            extracted_objects = self._extract_objects_with_llm_from_task(task_description, recipe)
            if extracted_objects:
                potential_objects.update(extracted_objects)
                
        # 从配方中提取物品名称
        if recipe and "ingredients" in recipe:
            for ingredient in recipe["ingredients"]:
                if isinstance(ingredient, str):
                    potential_objects.add(ingredient)
                elif isinstance(ingredient, dict) and "name" in ingredient:
                    potential_objects.add(ingredient["name"])
                    
        # 添加一些常用工具
        common_tools = ["knife", "cutting board", "pan", "pot", "bowl", "plate", "stove", "oven", "refrigerator"]
        for tool in common_tools:
            if task_description and tool.lower() in task_description.lower():
                potential_objects.add(tool)
                
        # 限制返回的物品数量
        return list(potential_objects)[:15]  # 最多返回15个物品
    
    def _extract_objects_with_llm_from_task(self, task_description, recipe):
        """使用LLM从任务描述中提取物品名称。"""
        try:
            provider_name = self.api_assignments.get('planning')
            if not provider_name:
                return []
                
            client = self._get_api_client(provider_name)
            model_name = self.api_providers[provider_name]['model_name']
            
            ingredients_str = ""
            if recipe and "ingredients" in recipe:
                ingredients = []
                for ingredient in recipe["ingredients"]:
                    if isinstance(ingredient, str):
                        ingredients.append(ingredient)
                    elif isinstance(ingredient, dict) and "name" in ingredient:
                        ingredients.append(ingredient["name"])
                ingredients_str = ", ".join(ingredients)
            
            prompt = f"""
            Extract a list of all specific objects (tools, ingredients, appliances) that might be needed for the following cooking task.
            
            Task: {task_description}
            
            Recipe ingredients: {ingredients_str}
            
            Return only a JSON array of object names, like this:
            ["knife", "cutting board", "tomato", "refrigerator"]
            """
            
            response = client.chat.completions.create(
                model=model_name,
                response_format={"type": "json_object"},
                messages=[{"role": "user", "content": prompt}]
            )
            response_str = response.choices[0].message.content
            
            # 处理可能的markdown格式
            if "```json" in response_str:
                response_str = response_str.split("```json\n")[1].split("```")[0]
            
            result = json.loads(response_str)
            if isinstance(result, dict) and "objects" in result:
                return result["objects"]
            elif isinstance(result, list):
                return result
            else:
                return []
                
        except Exception as e:
            print(f"[!] Error extracting objects from task with LLM: {e}")
            return []
    
    def _extract_objects_with_llm(self, scene_description):
        """使用LLM从场景描述中提取物品名称。"""
        try:
            provider_name = self.api_assignments.get('planning')
            if not provider_name:
                return []
                
            client = self._get_api_client(provider_name)
            model_name = self.api_providers[provider_name]['model_name']
            
            prompt = f"""
            Extract a list of all specific objects mentioned in the following scene description.
            Focus on identifying tools, ingredients, appliances, containers, and other physical objects.
            
            Scene Description:
            {scene_description}
            
            Return only a JSON array of object names, like this:
            ["knife", "cutting board", "tomato", "refrigerator"]
            """
            
            response = client.chat.completions.create(
                model=model_name,
                response_format={"type": "json_object"},
                messages=[{"role": "user", "content": prompt}]
            )
            response_str = response.choices[0].message.content
            
            # 处理可能的markdown格式
            if "```json" in response_str:
                response_str = response_str.split("```json\n")[1].split("```")[0]
            
            result = json.loads(response_str)
            if isinstance(result, dict) and "objects" in result:
                return result["objects"]
            elif isinstance(result, list):
                return result
            else:
                return []
                
        except Exception as e:
            print(f"[!] Error extracting objects with LLM: {e}")
            return []
            
    def _get_object_details(self, object_name):
        """查询物品或工具的详细信息。"""
        result = {}
        
        # 确保object_name是字符串
        if not isinstance(object_name, str):
            object_name = str(object_name)
            
        object_name_lower = object_name.lower()
        
        # 先在产品中查找
        for product in self.products_data:
            # 处理item_name可能不是字符串的情况
            item_name = product.get("item_name", "")
            if isinstance(item_name, str) and item_name.lower() == object_name_lower:
                result["type"] = "product"
                result["details"] = product
                
                # 查找对应的action2API映射
                action2api_name = product.get("action2API")
                if action2api_name:
                    action_info = self._get_action_mapping(action2api_name)
                    if action_info:
                        result["action_mapping"] = action_info
                
                return result
            
            # 处理action2API可能不是字符串的情况
            action2api = product.get("action2API")
            if action2api:
                if isinstance(action2api, str) and action2api.lower() == object_name_lower:
                    result["type"] = "product"
                    result["details"] = product
                    
                    action_info = self._get_action_mapping(action2api)
                    if action_info:
                        result["action_mapping"] = action_info
                    
                    return result
                elif str(action2api) == object_name:
                    result["type"] = "product"
                    result["details"] = product
                    
                    action_info = self._get_action_mapping(action2api)
                    if action_info:
                        result["action_mapping"] = action_info
                    
                    return result
        
        # 再在工具中查找
        for tool in self.tools_data:
            # 处理tool_name可能不是字符串的情况
            tool_name = tool.get("tool_name", "")
            if isinstance(tool_name, str) and tool_name.lower() == object_name_lower:
                result["type"] = "tool"
                result["details"] = tool
                
                # 查找对应的action2API映射
                action2api_name = tool.get("action2API")
                if action2api_name:
                    action_info = self._get_action_mapping(action2api_name)
                    if action_info:
                        result["action_mapping"] = action_info
                
                return result
            
            # 处理action2API可能不是字符串的情况
            action2api = tool.get("action2API")
            if action2api:
                if isinstance(action2api, str) and action2api.lower() == object_name_lower:
                    result["type"] = "tool"
                    result["details"] = tool
                    
                    action_info = self._get_action_mapping(action2api)
                    if action_info:
                        result["action_mapping"] = action_info
                    
                    return result
                elif str(action2api) == object_name:
                    result["type"] = "tool"
                    result["details"] = tool
                    
                    action_info = self._get_action_mapping(action2api)
                    if action_info:
                        result["action_mapping"] = action_info
                    
                    return result
                
        return None
        
    def _get_action_mapping(self, action2api_name):
        """根据action2API名称查找对应的动作映射。"""
        if not action2api_name or not self.action2api_data:
            return None
            
        # 确保action2api_name是字符串
        action2api_name_str = str(action2api_name) if not isinstance(action2api_name, str) else action2api_name
            
        # 在action2API数据中查找
        for action_mapping in self.action2api_data:
            # 检查最后一个键值对
            for action_name, api_name in action_mapping.items():
                # 处理api_name可能是整数或其他非字符串类型的情况
                if isinstance(api_name, str):
                    if api_name.lower() == action2api_name_str.lower():
                        return {
                            "action_name": action_name,
                            "api_name": api_name,
                            "full_mapping": action_mapping
                        }
                else:
                    # 如果api_name不是字符串，转换为字符串后比较
                    if str(api_name) == action2api_name_str:
                        return {
                            "action_name": action_name,
                            "api_name": api_name,
                            "full_mapping": action_mapping
                        }
        
        return None
        
    def get_action_by_object_name(self, object_name):
        """根据物品名称查找可以对其执行的动作。"""
        object_info = self._get_object_details(object_name)
        if not object_info:
            return None
            
        # 检查是否有action_mapping
        if "action_mapping" in object_info:
            return object_info["action_mapping"]
            
        # 如果没有直接的action_mapping，尝试从action2API字段获取
        if "details" in object_info:
            details = object_info["details"]
            action2api_name = details.get("action2API")
            if action2api_name:
                return self._get_action_mapping(action2api_name)
                
        return None
        
    def list_all_action_mappings(self):
        """列出所有可用的动作映射。"""
        if not self.action2api_data:
            return []
            
        mappings = []
        for action_mapping in self.action2api_data:
            # 找到最后一个键值对
            last_action = None
            last_api = None
            for action_name, api_name in action_mapping.items():
                last_action = action_name
                last_api = api_name
                
            if last_action is not None and last_api is not None:  # 使用is not None检查，允许0值
                mappings.append({
                    "action_name": last_action,
                    "api_name": last_api,
                    "full_mapping": action_mapping
                })
                
        return mappings
        
    def query_objects_info(self, object_names):
        """批量查询多个物品或工具的信息。"""
        results = {}
        for name in object_names:
            result = self._get_object_details(name)
            if result:
                results[name] = result
                
        return results

    def _get_final_plan_from_llm(self, planning_prompt):
        """调用最终的规划LLM。"""
        planning_provider = self.api_assignments['planning']
        planning_client = self._get_api_client(planning_provider)
        planning_model = self.api_providers[planning_provider]['model_name']
        
        print(f"[*] Stage 2: Calling final planner ({planning_model}) for decision...")
        try:
            response = planning_client.chat.completions.create(
                model=planning_model,
                response_format={"type": "json_object"},
                messages=[{"role": "user", "content": planning_prompt}]
            )
            response_str = response.choices[0].message.content
            if "```json" in response_str: response_str = response_str.split("```json\n")[1].split("```")[0]
            return json.loads(response_str)
        except Exception as e:
            print(f"[!] API Planning failed: {e}")
            return None

    def _get_decision_from_api_tools(self, pil_image, action_details, main_goal, memory_context, human_feedback):
        """
        统一的、基于工具调用的决策链。
        """
        print("[*] Executing Tool-Using API Chain...")
        
        # 1. 感知：调用所有可用的感知工具
        recipe = main_goal.get('recipe', {})
        ingredients = recipe.get('ingredients', [])
        
        # YOLO定量检测 (可选)
        detected_objects = self._get_yolo_detections(pil_image, ingredients) if self.use_yolo else []
        
        # VLM定性描述 (融合了YOLO的结果)
        scene_description = self._get_vlm_description(pil_image, detected_objects)
        
        # 语义地图静态知识
        spatial_knowledge = self._get_semantic_map_knowledge(main_goal)

        # 获取当前场景中可能相关的物品和工具信息
        # 从场景描述和检测结果中提取可能的物品名称
        potential_objects = self._extract_potential_objects(scene_description, detected_objects)
        objects_info = self.query_objects_info(potential_objects)
        
        # 2. 规划：将所有信息整合后，调用LLM进行最终规划
        planning_prompt = f"""
        **Role:** You are a meticulous cooking robot. Your mission is to interact with the environment to complete cooking tasks based on the provided dish and recipe.

        **Core Game Knowledge & Perception Strategy:**
        1.  **Order First:** Before cooking, you MUST navigate to the computer/laptop and interact with it to place an order.
        2.  **Active Perception via Pop-up:** Your primary method for identifying an object is to get very close and center it in your view. The game will then display a pop-up window with the object's name. You MUST use this mechanism to confirm an object's identity before interacting with it.
        3.  **Mouse Hover Tooltip:** When you move the mouse cursor over any object in the scene, a tooltip will automatically appear showing what the object is. You should use this feature to identify objects before interacting with them.
        4.  **Object Database:** You have access to a database of products and tools with detailed information. You can use this information to better understand the properties and locations of objects in the game.
        5.  **Action Mapping:** Each object has an "action2API" field that maps to specific actions you can perform on it. The Objects Database Information includes these mappings, showing which functions in local_actions.py can be used with each object.
        6.  **Interaction Modes:** Many objects require entering a specific mode before you can interact with them. The action mappings show which modes are available for each object.
        7.  **Navigation Functions:** Use the new navigation functions (move_forward, move_backward, move_left, move_right, search_for_object, approach_object, navigate_to_object) to find and approach objects. Always navigate to an object before attempting to interact with it.
        8.  **Object Finding Strategy:** If you can't find an object, first use search_for_object to look around, then navigate_to_object to approach it. If still not found, check if it's inside a container (refrigerator, cabinet) or needs to be purchased.
        9.  **Submit to Finish:** To complete the task, you MUST carry the final dish to the conveyor belt, place it down, and then click on the pop-up screen.
        10. **Parameter Types:** For functions requiring coordinates (x, y parameters), you MUST provide NUMERIC values, not object names. If you don't know the exact coordinates, use the relative_position field in the object database to estimate a reasonable position.
        11. **One Item at a Time:** You can only hold ONE item at a time in your hands. If you need to pick up something else, you MUST put down what you're currently holding first.
        12. **Container Exception:** If you're holding a container (pot, pan, bowl, etc.), you can add items to it by clicking on them. This doesn't count as picking up a second item.
        13. **Item Position:** Once you pick up an item, it will remain "in front of you" until you put it down or use it. The item moves with you as you navigate.
        14. **function_call:** parameters must match the function signature exactly.
        15. **MEMORY AND HISTORY (Your recent actions and human corrections):**
        {memory_context} # memory_context 现在应该包含之前的纠错历史

        **PERCEPTION_CONTEXT (Optional Inputs):**
        1.  **VLM Scene Description:**
            {scene_description}
        2.  **YOLO Detections:**
            {json.dumps(detected_objects, indent=2) if self.use_yolo else "Not used."}
        3.  **Semantic Map Knowledge:**
            {json.dumps(spatial_knowledge, indent=2, ensure_ascii=False)}
        4.  **Objects Database Information:**
            {json.dumps(objects_info, indent=2, ensure_ascii=False) if objects_info else "No specific object information available for current scene."}
        
        **AVAILABLE ACTIONS (with function signatures):**
        {json.dumps(action_details, indent=2)}
        
        **Human Feedback (Correction for the last action):**
        {human_feedback or 'None'}

        **YOUR TASK:**
        1. **Think Step-by-Step**: Synthesize all available perception context to make a decision...
        2. **Provide Your Final Output**: A single JSON object...
        """
        
        return self._get_final_plan_from_llm(planning_prompt)

    def _get_decision_from_hpc(self, pil_image, action_details, main_goal, memory_context, human_feedback):
        """HPC模式的决策获取"""
        # TODO: 实现HPC模式的决策逻辑
        return None
    
    def generate_sub_task_plan(self, recipe):
        """调用LLM，根据菜谱生成高层子任务规划。"""
        if self.mode != 'local_api':
            print("[!] Sub-task generation is only implemented for 'local_api' mode for now.")
            return ["place_order", "cook_dish", "submit_dish"] # 返回一个默认计划

        provider_name = self.api_assignments['planning'] # 复用规划模型
        client = self._get_api_client(provider_name)
        model_name = self.api_providers[provider_name]['model_name']
        
        # 提取菜谱中可能涉及的物品
        recipe_related_objects = []
        if recipe and "ingredients" in recipe:
            for ingredient in recipe["ingredients"]:
                if isinstance(ingredient, str):
                    recipe_related_objects.append(ingredient)
                elif isinstance(ingredient, dict) and "name" in ingredient:
                    recipe_related_objects.append(ingredient["name"])
        
        # 查询物品和工具信息
        objects_info = self.query_objects_info(recipe_related_objects)
        
        prompt = f"""
        You are a master chef planning how to cook a dish. Based on the following recipe, break it down into a logical sequence of high-level sub-tasks.
        
        **Core Game Knowledge:**
        - The entire process must start with a "place_order" task.
        - The entire process must end with a "submit_dish" task.
        - When the mouse cursor hovers over any object in the scene, a tooltip will appear showing what the object is. This feature helps identify objects before interacting with them.
        - You have access to a database of products and tools with detailed information. Use this information to better understand the properties and locations of objects in the game.
        - Each object has an "action2API" field that maps to specific actions you can perform on it. The Objects Database Information includes these mappings.
        - Many objects require entering a specific mode before you can interact with them. Consider these interaction requirements when planning sub-tasks.

        **Recipe:**
        {json.dumps(recipe, indent=2, ensure_ascii=False)}
        
        **Objects Database Information:**
        {json.dumps(objects_info, indent=2, ensure_ascii=False) if objects_info else "No specific object information available for this recipe."}

        **Your Task:**
        Generate a list of strings representing the sub-task sequence. The sequence must start with "place_order" and end with "submit_dish".
        Your output must be a single JSON object with one key, "sub_task_sequence".
        Example: {{"sub_task_sequence": ["place_order", "chop tomato", "fry egg", "combine ingredients", "submit_dish"]}}
        """
        print(f"[*] Calling {model_name} for sub-task planning...")
        try:
            response = client.chat.completions.create(
                model=model_name,
                response_format={"type": "json_object"},
                messages=[{"role": "user", "content": prompt}]
            )
            response_str = response.choices[0].message.content
            if "```json" in response_str:
                response_str = response_str.split("```json\n")[1].split("```")[0]
            return json.loads(response_str).get("sub_task_sequence", [])
        except Exception as e:
            print(f"[!] API Sub-task Planning failed: {e}")
            return []

    def decompose_task_to_functions(self, current_sub_task, recipe, available_actions):
        """将当前子任务分解为具体的函数调用序列。"""
        if self.mode != 'local_api':
            print("[!] Task decomposition is only implemented for 'local_api' mode for now.")
            return []

        provider_name = self.api_assignments['planning']
        client = self._get_api_client(provider_name)
        model_name = self.api_providers[provider_name]['model_name']
        
        # 提取当前子任务可能涉及的物品
        task_related_objects = self._extract_task_related_objects(current_sub_task, recipe)
        objects_info = self.query_objects_info(task_related_objects)
        
        prompt = f"""
        You are a cooking robot task planner. Your job is to break down a high-level cooking sub-task into a sequence of specific function calls.

        **Current Sub-task:** {current_sub_task}
        
        **Recipe Context:**
        {json.dumps(recipe, indent=2, ensure_ascii=False)}
        
        **Available Functions:**
        {json.dumps(available_actions, indent=2)}
        
        **Objects Database Information:**
        {json.dumps(objects_info, indent=2, ensure_ascii=False) if objects_info else "No specific object information available for this task."}
        
        **IMPORTANT PARAMETER GUIDELINES:**
        1. For functions requiring coordinates (x, y parameters), you MUST provide NUMERIC values (integers), not object names.
        2. Use the "relative_position" field in the Objects Database Information to estimate reasonable coordinates for objects.
        3. For functions like "Enter_bottle_dumping_mode(x, y, key)", use the estimated coordinates of the target object.
        4. Remember that when the mouse cursor hovers over any object in the scene, a tooltip will appear showing what the object is.
        5. Use the Objects Database Information to understand the properties and locations of objects needed for this task.
        6. Pay attention to the "action_mapping" field - it shows which functions can be used with each object.
        7. Many objects require entering a specific mode before interacting with them. Check the action mappings for the correct sequence.
        8. You can only hold ONE item at a time. If you need to pick up something else, put down what you're currently holding first.
        9. Exception: If holding a container (pot, pan, bowl), you can add items to it by clicking on them.
        10. Once you pick up an item, it remains "in front of you" until you put it down or use it.
        11. Always include navigation steps before interacting with objects. Use move_forward, move_backward, move_left, move_right, search_for_object, approach_object, or navigate_to_object.
        12. If you can't find an object, first use search_for_object to look around, then navigate_to_object to approach it. If still not found, check if it's inside a container (refrigerator, cabinet) or needs to be purchased.
        
        **Your Task:**
        Break down the sub-task "{current_sub_task}" into a logical sequence of function calls. Each function call should be represented as a JSON object with "function_name" and "estimated_parameters".
        
        **Example Output for coordinate-based functions:**
        {{
            "function_sequence": [
                {{"function_name": "Enter_bottle_dumping_mode", "estimated_parameters": {{"x": "olive_oil_bottle", "y": "cooking_pot", "key": "left"}}}},
                {{"function_name": "Carry_out__dumping_operation", "estimated_parameters": {{"key": "left"}}}},
                {{"function_name": "Escape_bottle_dumping_mode", "estimated_parameters": {{"key": "right"}}}}
            ],
            "reasoning": "To pour olive oil into pot, I need to enter dumping mode at the bottle location, perform the dumping, then exit"
        }}
        """
        
        print(f"[*] Calling {model_name} for task decomposition...")
        try:
            response = client.chat.completions.create(
                model=model_name,
                response_format={"type": "json_object"},
                messages=[{"role": "user", "content": prompt}]
            )
            response_str = response.choices[0].message.content
            if "```json" in response_str:
                response_str = response_str.split("```json\n")[1].split("```")[0]
            return json.loads(response_str)
        except Exception as e:
            print(f"[!] API Task Decomposition failed: {e}")
            return {}

    def _analyze_parameter_semantics(self, function_name, function_info):
        """分析函数参数的语义类型。"""
        
        # 基于函数名和描述判断参数语义
        function_desc = function_info.get("description", "").lower()
        function_name_lower = function_name.lower()
        
        # 相对移动函数的关键词
        relative_keywords = [
            'viewpoint', 'movement', 'rotate', 'adjust', 'move_related', 
            'spatial_rotation', 'horizontal_movement', 'vertical_movement',
            'aiming_position', 'water_container', 'move_downward', 'move_upward'
        ]
        
        # 绝对坐标函数的关键词
        absolute_keywords = [
            'enter', 'dumping_mode', 'smooth_move', 'position', 'click',
            'bottle_dumping', 'coordinate', 'location'
        ]
        
        # 判断函数类型
        is_relative = any(keyword in function_name_lower for keyword in relative_keywords)
        is_absolute = any(keyword in function_name_lower for keyword in absolute_keywords)
        
        if is_relative:
            return "relative_movement"
        elif is_absolute:
            return "absolute_coordinate"
        else:
            # 默认使用更安全的相对移动
            print(f"[*] 函数 {function_name} 类型不明确，默认使用相对移动语义")
            return "relative_movement"

    def fill_function_parameters(self, function_name, estimated_parameters, scene_context, recipe_context, available_actions):
        """根据场景上下文和菜谱上下文填充具体的函数参数，包括坐标获取。"""
        if self.mode != 'local_api':
            print("[!] Parameter filling is only implemented for 'local_api' mode for now.")
            return estimated_parameters

        # 检查函数签名，判断是否需要坐标参数
        function_info = available_actions.get(function_name, {})
        function_params = function_info.get("parameters", {})
        
        # 识别需要坐标的参数（通常是x, y参数）
        needs_coordinates = any(param in function_params for param in ['x', 'y'])
        
        if needs_coordinates:
            # 判断函数的参数语义类型
            param_semantic = self._analyze_parameter_semantics(function_name, function_info)
            return self._fill_parameters_with_semantics(function_name, estimated_parameters, scene_context, recipe_context, param_semantic)
        else:
            return self._fill_parameters_basic(function_name, estimated_parameters, scene_context, recipe_context)

    def _fill_parameters_with_semantics(self, function_name, estimated_parameters, scene_context, recipe_context, param_semantic):
        """根据参数语义填充函数参数。"""
        print(f"[*] 函数 {function_name} 需要坐标参数，语义类型: {param_semantic}")
        
        if param_semantic == "absolute_coordinate":
            return self._fill_absolute_coordinates(function_name, estimated_parameters, scene_context, recipe_context)
        elif param_semantic == "relative_movement":
            return self._fill_relative_movements(function_name, estimated_parameters, scene_context, recipe_context)
        else:
            print(f"[!] 未知的参数语义类型: {param_semantic}")
            return estimated_parameters

    def _fill_absolute_coordinates(self, function_name, estimated_parameters, scene_context, recipe_context):
        """填充绝对坐标参数 - 用于点击、定位等操作。"""
        print(f"[*] 填充绝对坐标参数...")
        
        filled_params = {}
        
        # 遍历所有参数，处理坐标参数
        for param_name, param_value in estimated_parameters.items():
            if param_name in ['x', 'y']:
                # 如果已经是数值类型，直接使用
                if isinstance(param_value, (int, float)):
                    filled_params[param_name] = int(param_value)  # 确保是整数
                    print(f"[*] 参数 '{param_name}' 已提供数值: {filled_params[param_name]}")
                # 如果是字符串但可以转换为数字，转换后使用
                elif isinstance(param_value, str) and param_value.replace('.', '', 1).isdigit():
                    filled_params[param_name] = int(float(param_value))  # 转换为整数
                    print(f"[*] 参数 '{param_name}' 的字符串值已转换为数值: {filled_params[param_name]}")
                # 如果是字符串（对象名），尝试查找物品并获取位置信息
                elif isinstance(param_value, str):
                    print(f"[*] 参数 '{param_name}' 的值是对象名 '{param_value}'，正在获取位置信息...")
                    
                    # 先查询物品数据库
                    object_info = self._get_object_details(param_value)
                    if object_info and 'details' in object_info:
                        details = object_info['details']
                        relative_position = details.get('relative_position', '')
                        
                        if relative_position:
                            print(f"[*] 从数据库获取到物品 '{param_value}' 的相对位置: {relative_position}")
                            # 根据相对位置估计坐标
                            estimated_coords = self._estimate_coordinates_from_position(relative_position, param_name)
                            filled_params[param_name] = estimated_coords
                            print(f"[*] 根据相对位置估计的 {param_name} 坐标: {filled_params[param_name]}")
                        else:
                            # 如果没有相对位置信息，尝试从场景描述中获取
                            coordinates = self._get_object_coordinates(param_value, scene_context)
                            if param_name == 'x':
                                filled_params[param_name] = coordinates.get('x', 640)
                            elif param_name == 'y':
                                filled_params[param_name] = coordinates.get('y', 360)
                            print(f"[*] 从场景描述估计的 {param_name} 坐标: {filled_params[param_name]}")
                    else:
                        # 如果在数据库中找不到物品，尝试从场景描述中获取
                        coordinates = self._get_object_coordinates(param_value, scene_context)
                        if param_name == 'x':
                            filled_params[param_name] = coordinates.get('x', 640)
                        elif param_name == 'y':
                            filled_params[param_name] = coordinates.get('y', 360)
                        print(f"[*] 从场景描述估计的 {param_name} 坐标: {filled_params[param_name]}")
                else:
                    # 其他类型的值，使用默认值
                    default_value = 640 if param_name == 'x' else 360
                    filled_params[param_name] = default_value
                    print(f"[*] 参数 '{param_name}' 类型不支持，使用默认值: {default_value}")
            else:
                # 非坐标参数直接复制
                filled_params[param_name] = param_value
        
        # 如果缺少x或y参数，使用默认值
        if 'x' not in filled_params:
            filled_params['x'] = 640
        if 'y' not in filled_params:
            filled_params['y'] = 360
            
        return filled_params
        
    def _estimate_coordinates_from_position(self, position_description, coord_type):
        """根据相对位置描述估计坐标。"""
        # 默认值
        default_x = 640
        default_y = 360
        
        # 常见位置的坐标映射
        position_map = {
            # 左侧区域
            "left": {"x": 200, "y": 360},
            "left side": {"x": 200, "y": 360},
            "left shelf": {"x": 200, "y": 300},
            "left shelves": {"x": 200, "y": 300},
            
            # 右侧区域
            "right": {"x": 1080, "y": 360},
            "right side": {"x": 1080, "y": 360},
            "right shelf": {"x": 1080, "y": 300},
            "right shelves": {"x": 1080, "y": 300},
            
            # 中央区域
            "center": {"x": 640, "y": 360},
            "middle": {"x": 640, "y": 360},
            "counter": {"x": 640, "y": 450},
            "countertop": {"x": 640, "y": 450},
            
            # 上下区域
            "top": {"x": 640, "y": 200},
            "upper": {"x": 640, "y": 200},
            "bottom": {"x": 640, "y": 500},
            "lower": {"x": 640, "y": 500},
            
            # 特定设备
            "stove": {"x": 640, "y": 300},
            "oven": {"x": 640, "y": 350},
            "refrigerator": {"x": 150, "y": 350},
            "fridge": {"x": 150, "y": 350},
            "sink": {"x": 800, "y": 350},
        }
        
        # 将描述转为小写以便匹配
        position_lower = position_description.lower()
        
        # 尝试匹配常见位置
        for key, coords in position_map.items():
            if key in position_lower:
                return coords[coord_type]
        
        # 如果没有匹配到，使用LLM分析位置描述
        try:
            provider_name = self.api_assignments.get('planning')
            if provider_name:
                client = self._get_api_client(provider_name)
                model_name = self.api_providers[provider_name]['model_name']
                
                prompt = f"""
                Based on this position description in a kitchen game: "{position_description}"
                Estimate a reasonable screen coordinate for the '{coord_type}' value.
                
                Screen resolution is 1280x720.
                For x coordinates: left=0, center=640, right=1280
                For y coordinates: top=0, center=360, bottom=720
                
                Return only a single integer value representing your best estimate.
                """
                
                response = client.chat.completions.create(
                    model=model_name,
                    messages=[{"role": "user", "content": prompt}]
                )
                
                result = response.choices[0].message.content.strip()
                # 尝试从结果中提取数字
                import re
                numbers = re.findall(r'\d+', result)
                if numbers:
                    return int(numbers[0])
            
        except Exception as e:
            print(f"[!] 使用LLM估计坐标失败: {e}")
        
        # 如果所有方法都失败，返回默认值
        return default_x if coord_type == 'x' else default_y

    def _fill_relative_movements(self, function_name, estimated_parameters, scene_context, recipe_context):
        """填充相对移动参数 - 用于视野控制、物体移动等操作。"""
        print(f"[*] 填充相对移动参数...")
        
        filled_params = {}
        
        # 对于相对移动，需要计算移动量而不是绝对坐标
        for param_name, param_value in estimated_parameters.items():
            if param_name in ['x', 'y']:
                # 如果已经是数值类型，直接使用
                if isinstance(param_value, (int, float)):
                    filled_params[param_name] = int(param_value)  # 确保是整数
                    print(f"[*] 参数 '{param_name}' 已提供数值: {filled_params[param_name]}")
                # 如果是字符串但可以转换为数字，转换后使用
                elif isinstance(param_value, str) and param_value.replace('.', '', 1).replace('-', '', 1).isdigit():
                    filled_params[param_name] = int(float(param_value))  # 转换为整数
                    print(f"[*] 参数 '{param_name}' 的字符串值已转换为数值: {filled_params[param_name]}")
                # 如果是字符串（对象名或方向描述），计算相对移动量
                elif isinstance(param_value, str):
                    # 如果是对象名，需要计算相对移动量
                    movement = self._calculate_relative_movement(param_name, param_value, scene_context, function_name)
                    filled_params[param_name] = movement
                    print(f"[*] 为 '{param_value}' 计算的相对 {param_name} 移动量: {movement}")
                else:
                    # 使用默认的小幅移动
                    default_movement = 50 if param_name == 'x' else 30
                    filled_params[param_name] = default_movement
                    print(f"[*] 使用默认 {param_name} 移动量: {default_movement}")
            else:
                # 非坐标参数直接复制
                filled_params[param_name] = param_value
        
        # 如果缺少x或y参数，使用默认小幅移动
        if 'x' not in filled_params:
            filled_params['x'] = 0
        if 'y' not in filled_params:
            filled_params['y'] = 0
            
        return filled_params

    def _calculate_relative_movement(self, param_name, target_description, scene_context, function_name):
        """计算相对移动量 - 用于视野控制等操作。"""
        print(f"[*] 计算相对移动量: {param_name} 方向，目标: {target_description}")
        
        # 使用AI来理解移动意图并计算合理的移动量
        provider_name = self.api_assignments.get('planning')
        if not provider_name:
            return self._get_default_movement(param_name, function_name)
            
        client = self._get_api_client(provider_name)
        model_name = self.api_providers[provider_name]['model_name']
        
        prompt = f"""
        You are a cooking robot movement controller. Your task is to calculate appropriate relative movement values for game controls.

        **Function:** {function_name}
        **Parameter:** {param_name} (relative movement)
        **Target/Intent:** {target_description}
        **Current Scene:** {scene_context}
        
        **Movement Guidelines:**
        - Small adjustments: 10-50 pixels (fine control)
        - Medium movements: 50-150 pixels (normal navigation)
        - Large movements: 150-300 pixels (major view changes)
        - For viewpoint control: typically 50-200 pixels
        - For aiming adjustments: typically 10-100 pixels
        - For object manipulation: typically 20-150 pixels
        
        **Movement Directions:**
        - X positive = right, X negative = left
        - Y positive = down, Y negative = up
        
        **Your Task:**
        Based on the function name, target description, and scene context, calculate an appropriate relative movement value.
        Consider what the robot is trying to achieve and provide a reasonable movement amount.
        
        **Output Format:**
        {{
            "movement_value": 75,
            "reasoning": "For viewpoint adjustment to look at the stove, a medium rightward movement is appropriate"
        }}
        """
        
        try:
            response = client.chat.completions.create(
                model=model_name,
                response_format={"type": "json_object"},
                messages=[{"role": "user", "content": prompt}]
            )
            response_str = response.choices[0].message.content
            if "```json" in response_str:
                response_str = response_str.split("```json\n")[1].split("```")[0]
            result = json.loads(response_str)
            
            movement_value = result.get("movement_value", self._get_default_movement(param_name, function_name))
            reasoning = result.get("reasoning", "无推理")
            
            print(f"[*] 移动量计算推理: {reasoning}")
            return movement_value
            
        except Exception as e:
            print(f"[!] 相对移动量计算失败: {e}")
            return self._get_default_movement(param_name, function_name)

    def _get_default_movement(self, param_name, function_name):
        """获取默认的移动量。"""
        # 根据函数类型提供合理的默认值
        if 'viewpoint' in function_name.lower():
            return 100 if param_name == 'x' else 80
        elif 'aiming' in function_name.lower():
            return 30 if param_name == 'x' else 25
        elif 'adjustment' in function_name.lower():
            return 50 if param_name == 'x' else 40
        else:
            return 75 if param_name == 'x' else 60

    def _get_object_coordinates(self, target_object, scene_context):
        """通过感知系统获取对象坐标。"""
        print(f"[*] 正在获取对象 '{target_object}' 的坐标...")
        
        # 方法1: 检查当前场景中是否能看到目标对象
        if self._is_object_visible_in_scene(target_object, scene_context):
            print(f"[*] 在当前场景中找到对象 '{target_object}'")
            # 方法1a: 如果有YOLO检测器，尝试检测对象
            if self.local_detector:
                print("[*] 尝试使用YOLO检测器获取精确坐标...")
                # TODO: 需要当前截图来进行检测
                # detections = self.local_detector.find_objects(current_image, [target_object])
                # if detections:
                #     return {"x": detections[0]["center_x"], "y": detections[0]["center_y"]}
            
            # 方法1b: 使用VLM分析场景描述来估计坐标
            print("[*] 使用VLM分析当前场景来估计坐标...")
            estimated_coords = self._estimate_coordinates_from_scene(target_object, scene_context)
            return estimated_coords
        else:
            # 方法2: 对象不在当前视野中，需要主动搜索
            print(f"[!] 对象 '{target_object}' 不在当前视野中，需要主动搜索")
            return self._search_for_object(target_object)

    def _is_object_visible_in_scene(self, target_object, scene_context):
        """判断目标对象是否在当前场景中可见。"""
        # 简单的文本匹配检查
        target_keywords = target_object.lower().replace('_', ' ').split()
        scene_lower = scene_context.lower()
        
        # 检查目标对象的关键词是否在场景描述中
        for keyword in target_keywords:
            if keyword in scene_lower:
                return True
        
        # 检查常见的同义词
        synonyms = {
            'bottle': ['bottle', 'container', 'flask'],
            'pot': ['pot', 'pan', 'cookware'],
            'knife': ['knife', 'blade', 'cutter'],
            'plate': ['plate', 'dish', 'platter']
        }
        
        for keyword in target_keywords:
            if keyword in synonyms:
                for synonym in synonyms[keyword]:
                    if synonym in scene_lower:
                        return True
        
        return False

    def _search_for_object(self, target_object):
        """主动搜索目标对象。"""
        print(f"[*] 开始主动搜索对象: {target_object}")
        
        # 生成搜索策略
        search_strategy = self._generate_search_strategy(target_object)
        
        if search_strategy:
            print(f"[*] 搜索策略: {search_strategy.get('strategy', '环视搜索')}")
            # 返回建议的搜索位置
            return search_strategy.get('suggested_coordinates', {"x": 640, "y": 360})
        else:
            print("[!] 无法生成搜索策略，使用默认位置")
            return {"x": 640, "y": 360}

    def _generate_search_strategy(self, target_object):
        """生成主动搜索策略。"""
        provider_name = self.api_assignments['planning']
        client = self._get_api_client(provider_name)
        model_name = self.api_providers[provider_name]['model_name']
        
        prompt = f"""
        You are a cooking robot navigation AI. The robot needs to find a specific object that is not currently visible.

        **Target Object:** {target_object}
        
        **Kitchen Layout Knowledge:**
        - Ingredients and bottles are usually on shelves or countertops
        - Cooking utensils are near the stove or in drawers
        - Plates and bowls are in cabinets or on shelves
        - Fresh ingredients might be in the refrigerator
        
        **Common Search Locations (screen coordinates for 1280x720):**
        - Left shelves: x=200-300, y=200-500
        - Right shelves: x=980-1180, y=200-500  
        - Central counter: x=500-800, y=400-600
        - Stove area: x=600-800, y=200-400
        - Refrigerator: x=100-250, y=300-600
        
        **Your Task:**
        Generate a search strategy for finding the target object. Suggest where the robot should look first.
        
        **Output Format:**
        {{
            "strategy": "Look in the left shelves where ingredients are typically stored",
            "suggested_coordinates": {{"x": 250, "y": 350}},
            "reasoning": "Bottles are usually stored on shelves..."
        }}
        """
        
        try:
            response = client.chat.completions.create(
                model=model_name,
                response_format={"type": "json_object"},
                messages=[{"role": "user", "content": prompt}]
            )
            response_str = response.choices[0].message.content
            if "```json" in response_str:
                response_str = response_str.split("```json\n")[1].split("```")[0]
            result = json.loads(response_str)
            print(f"[*] 搜索推理: {result.get('reasoning', '无')}")
            return result
        except Exception as e:
            print(f"[!] 搜索策略生成失败: {e}")
            return None

    def _estimate_coordinates_from_scene(self, target_object, scene_context):
        """基于场景描述估计对象坐标。"""
        provider_name = self.api_assignments.get('scene_understanding')
        if not provider_name:
            print("[!] 没有配置scene_understanding，使用默认坐标")
            return {"x": 640, "y": 360}
            
        client = self._get_api_client(provider_name)
        model_name = self.api_providers[provider_name]['model_name']
        
        prompt = f"""
        You are a spatial reasoning AI. Based on the scene description, estimate the screen coordinates for the target object.

        **Target Object:** {target_object}
        **Scene Description:** {scene_context}
        
        **Screen Resolution:** Assume 1280x720 (typical game window)
        **Coordinate System:** (0,0) is top-left, (1280,720) is bottom-right
        
        **Common Object Positions:**
        - Counter/workspace: usually in center-bottom area (y: 400-600)
        - Stove/cooking area: usually in upper-center (y: 200-400)  
        - Storage/shelves: usually on sides (x: 100-300 or 980-1180)
        
        **Your Task:**
        Provide reasonable screen coordinates for the target object based on the scene description.
        
        **Output Format:**
        {{
            "x": 640,
            "y": 360,
            "reasoning": "Based on the scene description, the object appears to be..."
        }}
        """
        
        try:
            response = client.chat.completions.create(
                model=model_name,
                response_format={"type": "json_object"},
                messages=[{"role": "user", "content": prompt}]
            )
            response_str = response.choices[0].message.content
            if "```json" in response_str:
                response_str = response_str.split("```json\n")[1].split("```")[0]
            result = json.loads(response_str)
            print(f"[*] 坐标估计推理: {result.get('reasoning', '无')}")
            return {"x": result.get("x", 640), "y": result.get("y", 360)}
        except Exception as e:
            print(f"[!] 坐标估计失败: {e}")
            return {"x": 640, "y": 360}  # 默认屏幕中心

    def _fill_parameters_basic(self, function_name, estimated_parameters, scene_context, recipe_context):
        """填充不需要坐标的基本函数参数。"""
        provider_name = self.api_assignments['planning']
        client = self._get_api_client(provider_name)
        model_name = self.api_providers[provider_name]['model_name']
        
        prompt = f"""
        You are a cooking robot parameter filler. Your job is to fill in the specific parameters for a function call based on the current scene and recipe context.

        **Function to Execute:** {function_name}
        **Estimated Parameters:** {json.dumps(estimated_parameters, indent=2)}
        
        **Current Scene Context:**
        {scene_context}
        
        **Recipe Context:**
        {json.dumps(recipe_context, indent=2, ensure_ascii=False)}
        
        **Your Task:**
        Based on the scene description and recipe context, provide the specific, concrete parameters for the function call. Make sure the parameters match the function signature exactly.
        
        **Output Format:**
        {{
            "filled_parameters": {{"param1": "value1", "param2": "value2"}},
            "reasoning": "I chose these parameters because..."
        }}
        """
        
        print(f"[*] Calling {model_name} for basic parameter filling...")
        try:
            response = client.chat.completions.create(
                model=model_name,
                response_format={"type": "json_object"},
                messages=[{"role": "user", "content": prompt}]
            )
            response_str = response.choices[0].message.content
            if "```json" in response_str:
                response_str = response_str.split("```json\n")[1].split("```")[0]
            result = json.loads(response_str)
            return result.get("filled_parameters", estimated_parameters)
        except Exception as e:
            print(f"[!] API Parameter Filling failed: {e}")
            return estimated_parameters


# ai_connector.py (在 AIConnector 类中新增)

    def interpret_human_hint(self, hint: str, available_actions: dict):
        """将人类的自然语言提示，转换为一个具体的、可执行的函数调用JSON。"""
        provider_name = self.api_assignments['planning'] # 复用规划模型
        client = self._get_api_client(provider_name)
        model_name = self.api_providers[provider_name]['model_name']
        
        prompt = f"""
        You are an AI assistant that translates a human's natural language command into a precise, executable function call for a game-playing robot.

        **Human's Command/Hint:** "{hint}"

        **Available Functions (with signatures and descriptions):**
        {json.dumps(available_actions, indent=2)}

        **Your Task:**
        1.  Analyze the human's command.
        2.  Choose the MOST appropriate function from the "Available Functions" list.
        3.  Determine the correct parameters for the chosen function based on the command.
        4.  If the command implies coordinates but doesn't provide them (e.g., "click the knife"), use your best guess for `x` and `y` (e.g., center of the screen like 640, 360).
        5.  Your output MUST be a single JSON object containing "action" and "parameters", matching the format of a robot's decision.

        **Example:**
        If the human says "pick up the knife on the counter", and an action is `pick_up(key: str)`, your output should be:
        {{
            "action": "pick_up",
            "parameters": {{ "key": "left" }}
        }}
        
        If the human says "go to the fridge", and an action is `Maps_to_object(object_name: str)`, your output should be:
        {{
            "action": "navigate_to_object",
            "parameters": {{ "object_name": "refrigerator" }}
        }}

        Now, generate the JSON for the given human command.
        """
        
        print(f"[*] Calling {model_name} to interpret human hint...")
        try:
            response = client.chat.completions.create(
                model=model_name,
                response_format={"type": "json_object"},
                messages=[{"role": "user", "content": prompt}]
            )
            response_str = response.choices[0].message.content
            if "```json" in response_str:
                response_str = response_str.split("```json\n")[1].split("```")[0]
            
            return json.loads(response_str)
        except Exception as e:
            print(f"[!] API call to interpret hint failed: {e}")
            return None
        
        
# ai_connector.py (在 AIConnector 类中新增)

    def answer_diagnostic_question(self, user_question: str, original_decision: dict, full_planning_prompt: str):
        """
        接收一个关于AI决策的问题，并调用LLM来生成解释。
        """
        provider_name = self.api_assignments['planning'] # 复用规划模型
        client = self._get_api_client(provider_name)
        model_name = self.api_providers[provider_name]['model_name']

        # 构建一个专门用于解释的Prompt
        explanation_prompt = f"""
        You are the AI agent that just made a decision in a game. Your task is to explain your reasoning to a human supervisor who has a question.

        **This was the full context and prompt you received to make your decision:**
        --- START OF ORIGINAL CONTEXT ---
        {full_planning_prompt}
        --- END OF ORIGINAL CONTEXT ---

        **Based on that context, this was the decision you made:**
        {json.dumps(original_decision, indent=2)}

        **Now, the human supervisor has the following question about your decision:**
        "{user_question}"

        **Your Task:**
        Answer the human's question clearly and concisely. Explain your thought process based ONLY on the context provided above. Do not make up new information. Your answer should be in natural language.
        """

        print("[*] Calling LLM to generate an explanation for the human...")
        try:
            response = client.chat.completions.create(
                model=model_name,
                # 注意：这里不需要JSON格式输出
                messages=[{"role": "user", "content": explanation_prompt}]
            )
            return response.choices[0].message.content
        except Exception as e:
            print(f"[!] API call to generate explanation failed: {e}")
            return "Sorry, I encountered an error while trying to explain my reasoning."
        
        
    def verify_action_success(self, after_action_image_pil, action_taken, expected_outcome_text):
        """
        【新增】调用VLM，判断一个动作是否成功执行。
        """
        print("[*] Verifying action success...")
        
        buffered = io.BytesIO()
        after_action_image_pil.save(buffered, format="PNG")
        img_base64 = base64.b64encode(buffered.getvalue()).decode('utf-8')
        
        provider_name = self.api_assignments['scene_understanding']
        client = self._get_api_client(provider_name)
        model_name = self.api_providers[provider_name]['model_name']

        prompt = f"""
        You are a meticulous QA checker for a robot in a cooking game. The robot just performed an action. Your task is to look at the screen AFTER the action and determine if it was successful.

        **1. Action Performed by Robot:**
        {json.dumps(action_taken, indent=2)}

        **2. Expected Outcome:**
        "{expected_outcome_text}"

        **3. Screen AFTER the action:**
        (See the attached image)

        **Your Task:**
        Analyze the image and determine if the action achieved its expected outcome. For example, if the action was `pick_up('lemon')`, check if the agent is now holding a lemon.

        **Output Format:**
        Respond with a single JSON object: {{"success": true/false, "reasoning": "A brief explanation of your conclusion."}}
        """

        try:
            response = client.chat.completions.create(
                model=model_name,
                response_format={"type": "json_object"},
                messages=[{"role": "user", "content": [{"type": "text", "text": prompt}, {"type": "image_url", "image_url": {"url": f"data:image/png;base64,{img_base64}"}}]}]
            )
            response_str = response.choices[0].message.content
            result = json.loads(response_str)
            print(f"[*] Verification Result: {'Success' if result.get('success') else 'Failure'}. Reason: {result.get('reasoning')}")
            return result
        except Exception as e:
            print(f"[!] VLM Verification failed: {e}")
            return {"success": False, "reasoning": "VLM verification call failed."}