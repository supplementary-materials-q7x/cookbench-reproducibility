import json
import re  # 导入正则表达式模块
import sys
from collections import Counter

def analyze_steps_in_json(file_path):
    """
    分析JSON文件中每个条目'output'字段的Step数量、分布及平均值。

    Args:
        file_path (str): JSON文件的路径。
    """
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
    except FileNotFoundError:
        print(f"错误：文件未找到 -> {file_path}")
        return
    except json.JSONDecodeError:
        print(f"错误：文件不是有效的JSON格式 -> {file_path}")
        return
    except Exception as e:
        print(f"读取文件时发生未知错误: {e}")
        return

    step_counts = []
    for item in data:
        output_text = item.get("output", "")
        
        # 使用正则表达式查找所有 "Step " 后跟一个或多个数字的模式
        # re.findall会返回所有匹配项的列表，例如 ['Step 1', 'Step 2', 'Step 10']
        # 这种方法不受换行符或步骤之间其他文本的影响
        steps_found = re.findall(r'Step \d+', output_text)
        
        num_steps = len(steps_found)
        step_counts.append(num_steps)

    if not step_counts:
        print("数据为空或未找到任何 'output' 字段。")
        return

    # 使用Counter统计step数量的分布
    distribution = Counter(step_counts)

    # 计算平均数
    average = sum(step_counts) / len(step_counts)

    # --- 打印结果 ---
    print("Output中Step数量的分布情况：")
    # 对分布结果按步骤数量进行排序，以便更清晰地展示
    for steps, count in sorted(distribution.items()):
        print(f"  - 包含 {steps} 个Step的条目有 {count} 个")

    print(f"\n所有条目的平均Step数量为: {average:.2f}")


if __name__ == "__main__":
    # 检查命令行是否提供了文件名参数
    if len(sys.argv) < 2:
        print("请提供JSON文件的路径作为参数。")
        print("用法: python analyze_json.py <你的文件名.json>")
    else:
        json_file_path = r"xxx"
        analyze_steps_in_json(json_file_path)