# local_detector.py
from ultralytics import YOLO
from PIL import Image
# from ultralytics.models.yolo.world.model import YOLO_World

class LocalDetector:
    def __init__(self, model_path):
        """
        初始化本地检测器。
        推荐使用官方模型名称（如 'yolo_world_v2_m.pt'），ultralytics会自动下载。
        """
        self.model = None
        try:
            # ultralytics库会自动处理模型下载和缓存
            loaded_model = YOLO(model_path).to(device='cuda')
            
            # 关键修复：不再需要严格的类型检查，只检查必要的方法是否存在即可
            if hasattr(loaded_model, 'set_classes') and callable(loaded_model.set_classes):
                self.model = loaded_model
                print(f"[*] Local YOLO-World detector loaded successfully (model: {model_path}).")
            else:
                print(f"[!] 错误: YOLO('{model_path}') 返回了非预期的对象类型，无法进行检测。请确保模型路径或名称正确。")

        except Exception as e:
            print(f"[!] 加载本地YOLO模型时发生严重错误: {e}")


        except Exception as e:
            print(f"[!] 加载本地YOLO模型时发生严重错误: {e}")

    def find_objects(self, pil_image, text_queries: list):
        """在图像中查找一组文本描述的物体。"""
        if not self.model or not text_queries:
            return []
            
        self.model.set_classes(text_queries)
        results = self.model.predict(source=pil_image, verbose=False)
        
        detections = []
        if results:
            for box in results[0].boxes:
                xyxy = [int(i) for i in box.xyxy[0].tolist()]
                center_x = int((xyxy[0] + xyxy[2]) / 2)
                center_y = int((xyxy[1] + xyxy[3]) / 2)
                detections.append({
                    "label": self.model.names[int(box.cls)],
                    "confidence": box.conf[0].item(),
                    "bounding_box": xyxy,
                    "center": {"x": center_x, "y": center_y}
                })
        return detections
