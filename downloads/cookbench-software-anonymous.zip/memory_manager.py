# memory_manager.py
import json
from collections import deque
import time

class MemoryManager:
    def __init__(self, max_history_len=10):
        # 记忆属性被命名为 'short_term_memory'
        self.short_term_memory = deque(maxlen=max_history_len)
        self.task_goal = ""
        self.recipe = {}
        self.sub_task_plan = []
        self.current_sub_task_index = 0
        self.current_function_sequence = []
        self.current_function_index = 0
        print("[*] 记忆管理器已初始化。")

    def update_task(self, goal, recipe, sub_tasks):
        """更新当前的主任务、菜谱和子任务计划。"""
        self.task_goal = goal
        self.recipe = recipe
        self.sub_task_plan = sub_tasks
        print(f"[*] 任务已更新。目标: {self.task_goal}。 子任务: {self.sub_task_plan}")

    def add_memory(self, observation, executed_decision, original_decision=None, human_correction=None):
        """
        添加一条新的记忆。这是唯一的、统一的函数，
        能同时处理常规AI决策和经人类修正后的决策。
        """
        entry = {
            "timestamp": time.time(),
            "observation": observation,
            "original_decision": original_decision,   # AI最初的想法
            "human_correction": human_correction,    # 人类的指令
            "executed_decision": executed_decision,  # 最终执行的动作
        }
        # 【关键修正】将记忆添加到正确的属性中：self.short_term_memory
        self.short_term_memory.append(entry)
        print(f"[*] 新记忆已添加。当前记忆容量: {len(self.short_term_memory)}")

    def get_context_for_prompt(self):
        """为Prompt生成格式化的记忆上下文。"""
        current_sub_task = self.get_current_sub_task()
        context = {
            "task_goal": self.task_goal,
            "recipe": self.recipe,
            "sub_task_plan": self.sub_task_plan,
            "current_sub_task": current_sub_task,
            "current_sub_task_index": self.current_sub_task_index,
            "current_function_sequence": self.current_function_sequence,
            "current_function_index": self.current_function_index,
            "recent_history": list(self.short_term_memory) # 这里也使用正确的属性名
        }
        return json.dumps(context, indent=2, ensure_ascii=False)

    def get_current_sub_task(self):
        """获取当前正在执行的子任务。"""
        if 0 <= self.current_sub_task_index < len(self.sub_task_plan):
            return self.sub_task_plan[self.current_sub_task_index]
        return None

    def advance_to_next_sub_task(self):
        """推进到下一个子任务。"""
        self.current_sub_task_index += 1
        self.current_function_sequence = []
        self.current_function_index = 0
        next_task = self.get_current_sub_task()
        if next_task:
            print(f"[*] 推进到子任务 {self.current_sub_task_index + 1}: {next_task}")
        else:
            print("[*] 所有子任务已完成。")

    def set_function_sequence(self, function_sequence):
        """设置当前子任务的函数序列。"""
        self.current_function_sequence = function_sequence
        self.current_function_index = 0
        print(f"[*] 已设置函数序列，包含 {len(function_sequence)} 个函数。")

    def advance_to_next_function(self):
        """推进到下一个函数。"""
        self.current_function_index += 1

    def get_current_function(self):
        """获取当前应该执行的函数。"""
        if 0 <= self.current_function_index < len(self.current_function_sequence):
            return self.current_function_sequence[self.current_function_index]
        return None

    def is_current_sub_task_complete(self):
        """检查当前子任务是否完成。"""
        return self.current_function_index >= len(self.current_function_sequence)

    def is_all_tasks_complete(self):
        """检查所有任务是否完成。"""
        return self.current_sub_task_index >= len(self.sub_task_plan)

    def clear(self):
        """清空所有记忆。"""
        self.short_term_memory.clear()
        self.task_goal = ""
        self.recipe = {}
        self.sub_task_plan = []
        self.current_sub_task_index = 0
        self.current_function_sequence = []
        self.current_function_index = 0