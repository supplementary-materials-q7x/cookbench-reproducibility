# raw_input_controller.py
import ctypes
import time

# 定义一系列Windows API所需的结构体和常量
PUL = ctypes.POINTER(ctypes.c_ulong)
class KeyBdInput(ctypes.Structure):
    _fields_ = [("wVk", ctypes.c_ushort), ("wScan", ctypes.c_ushort), ("dwFlags", ctypes.c_ulong), ("time", ctypes.c_ulong), ("dwExtraInfo", PUL)]
class HardwareInput(ctypes.Structure):
    _fields_ = [("uMsg", ctypes.c_ulong), ("wParamL", ctypes.c_short), ("wParamH", ctypes.c_ushort)]
class MouseInput(ctypes.Structure):
    _fields_ = [("dx", ctypes.c_long), ("dy", ctypes.c_long), ("mouseData", ctypes.c_ulong), ("dwFlags", ctypes.c_ulong), ("time", ctypes.c_ulong), ("dwExtraInfo", PUL)]
class Input_I(ctypes.Union):
    _fields_ = [("ki", KeyBdInput), ("mi", MouseInput), ("hi", HardwareInput)]
class Input(ctypes.Structure):
    _fields_ = [("type", ctypes.c_ulong), ("ii", Input_I)]

# 输入类型
INPUT_MOUSE = 0
INPUT_KEYBOARD = 1

# 键盘事件常量
KEYEVENTF_KEYUP = 0x0002
KEYEVENTF_UNICODE = 0x0004
KEYEVENTF_SCANCODE = 0x0008

# 鼠标事件常量
MOUSEEVENTF_MOVE = 0x0001
MOUSEEVENTF_LEFTDOWN = 0x0002
MOUSEEVENTF_LEFTUP = 0x0004
MOUSEEVENTF_RIGHTDOWN = 0x0008
MOUSEEVENTF_RIGHTUP = 0x0010
MOUSEEVENTF_MIDDLEDOWN = 0x0020
MOUSEEVENTF_MIDDLEUP = 0x0040
MOUSEEVENTF_WHEEL = 0x0800
MOUSEEVENTF_ABSOLUTE = 0x8000

# 常用按键的虚拟按键码 (Virtual-Key Codes)
VK_CODE = {
    'backspace': 0x08, 'tab': 0x09, 'clear': 0x0c, 'enter': 0x0d, 'shift': 0x10, 'ctrl': 0x11,
    'alt': 0x12, 'pause': 0x13, 'caps_lock': 0x14, 'esc': 0x1b, 'space': 0x20,
    'w': 0x57, 'a': 0x41, 's': 0x53, 'd': 0x44, 'e': 0x45, 'q': 0x51, 'r': 0x52,
    'left': 0x25, 'up': 0x26, 'right': 0x27, 'down': 0x28
}

class RawInputController:
    """
    一个使用ctypes和SendInput API的底层输入控制器。
    """
    def _send_input(self, input_struct):
        ctypes.windll.user32.SendInput(1, ctypes.byref(input_struct), ctypes.sizeof(input_struct))

    def key_down(self, key: str):
        """按下指定的键"""
        if key.lower() not in VK_CODE:
            raise ValueError(f"Unsupported key: {key}")
        extra = ctypes.c_ulong(0)
        ii_ = Input_I()
        ii_.ki = KeyBdInput(VK_CODE[key.lower()], 0, 0, 0, ctypes.pointer(extra))
        self._send_input(Input(INPUT_KEYBOARD, ii_))

    def key_up(self, key: str):
        """松开指定的键"""
        if key.lower() not in VK_CODE:
            raise ValueError(f"Unsupported key: {key}")
        extra = ctypes.c_ulong(0)
        ii_ = Input_I()
        ii_.ki = KeyBdInput(VK_CODE[key.lower()], 0, KEYEVENTF_KEYUP, 0, ctypes.pointer(extra))
        self._send_input(Input(INPUT_KEYBOARD, ii_))

    def key_press(self, key: str, delay: float = 0.01):
        """完整地按一次键（按下后迅速松开）"""
        self.key_down(key)
        time.sleep(delay)
        self.key_up(key)
        
    def mouse_down(self, button: str = 'left'):
        """按下鼠标按键"""
        flag_map = {'left': MOUSEEVENTF_LEFTDOWN, 'right': MOUSEEVENTF_RIGHTDOWN, 'mid': MOUSEEVENTF_MIDDLEDOWN}
        if button.lower() not in flag_map:
            raise ValueError(f"Unsupported mouse button: {button}")
            
        extra = ctypes.c_ulong(0)
        ii_ = Input_I()
        ii_.mi = MouseInput(0, 0, 0, flag_map[button.lower()], 0, ctypes.pointer(extra))
        self._send_input(Input(INPUT_MOUSE, ii_))

    def mouse_up(self, button: str = 'left'):
        """松开鼠标按键"""
        flag_map = {'left': MOUSEEVENTF_LEFTUP, 'right': MOUSEEVENTF_RIGHTUP, 'mid': MOUSEEVENTF_MIDDLEUP}
        if button.lower() not in flag_map:
            raise ValueError(f"Unsupported mouse button: {button}")

        extra = ctypes.c_ulong(0)
        ii_ = Input_I()
        ii_.mi = MouseInput(0, 0, 0, flag_map[button.lower()], 0, ctypes.pointer(extra))
        self._send_input(Input(INPUT_MOUSE, ii_))

    def click(self, button: str = 'left'):
        """完整地点击一次鼠标"""
        self.mouse_down(button)
        time.sleep(0.01)
        self.mouse_up(button)

    def mouse_move_relative(self, dx=0, dy=0):
        """相对移动鼠标，用于视角转动"""
        extra = ctypes.c_ulong(0)
        ii_ = Input_I()
        ii_.mi = MouseInput(dx, dy, 0, MOUSEEVENTF_MOVE, 0, ctypes.pointer(extra))
        self._send_input(Input(INPUT_MOUSE, ii_))

    def mouse_move_absolute(self, x, y):
        """绝对移动鼠标，用于点击UI元素"""
        screen_width = ctypes.windll.user32.GetSystemMetrics(0)
        screen_height = ctypes.windll.user32.GetSystemMetrics(1)
        nx = int(x * 65535 / screen_width)
        ny = int(y * 65535 / screen_height)
        
        extra = ctypes.c_ulong(0)
        ii_ = Input_I()
        ii_.mi = MouseInput(nx, ny, 0, MOUSEEVENTF_MOVE | MOUSEEVENTF_ABSOLUTE, 0, ctypes.pointer(extra))
        self._send_input(Input(INPUT_MOUSE, ii_))

    def scroll_wheel(self, delta: int):
        """滚动鼠标滚轮。正数向上，负数向下。"""
        extra = ctypes.c_ulong(0)
        ii_ = Input_I()
        # delta * 120 是Windows的标准滚动单位
        ii_.mi = MouseInput(0, 0, delta * 120, MOUSEEVENTF_WHEEL, 0, ctypes.pointer(extra))
        self._send_input(Input(INPUT_MOUSE, ii_))