import json
import os
import time
import numpy as np
from openai import OpenAI
from tqdm import tqdm

# --- 1. 配置信息 ---
# !!! 请根据您的实际情况修改此工作目录 !!!
WORKING_DIRECTORY = "xxx"
OPENAI_API_KEY = os.environ.get("OPENAI_API_KEY", "")
OPENAI_API_BASE_URL = os.environ.get("OPENAI_API_BASE_URL", "https://api.example.com/v1/")
GENERATOR_MODEL = "gpt-4.1"

# 重试配置
MAX_RETRIES = 3
RETRY_DELAY = 2

# 文件路径
INPUT_JSON_PATH = os.path.join(WORKING_DIRECTORY, "classics 1.json")
DECOMPOSED_OUTPUT_PATH = os.path.join(WORKING_DIRECTORY, "decomposed_recipes.json")
AGGREGATED_OUTPUT_PATH = os.path.join(WORKING_DIRECTORY, "aggregated_step_counts.json")

# --- 2. 初始化与函数定义 (与之前版本相同) ---
try:
    client = OpenAI(api_key=OPENAI_API_KEY, base_url=OPENAI_API_BASE_URL)
except Exception as e:
    print(f"初始化OpenAI客户端时出错: {e}"); exit()

PROMPT_TEMPLATE = """
你是一个顶级的机器人任务规划专家。你的任务是将高级烹饪菜谱分解为一个 **带有状态备注的、端到端的、完整的** 任务动作序列。

# 标准任务流程 (必须遵守):
每一个完整的任务都必须严格遵循以下四段式结构：
1.  **接取订单**: 任务必须从 `goto(电脑)` 开始，然后使用 `点击` 动作选择对应的菜品订单。
2.  **执行菜谱**: 严格按照输入的菜谱文本，将其分解为细粒度的原子动作序列。
3.  **装盘**: 在烹饪结束后，必须将所有成品装入一个干净的盘子中。
4.  **提交菜品**: 最后，必须 `拿起` 装有成品的盘子，`goto(传送台)`，然后 `放下(盘子, on=传送台)` 来完成整个任务。

# 允许的原子动作集:
你必须只使用以下定义的动作来构建流程：
- goto(物体/位置)
- 拿起(物体)
- 放下(物体, [on=目标位置])
- 水平移动到(目标位置)
- 倾斜(物体)
- 放平(物体)
- 切割(物体, [with=工具])
- 启动(设备)
- 关闭(设备)
- 等待(时间)
- 打开(物体)
- 关闭(物体)
- 舀起(物体, [with=工具])
- 点击(物体)

# 输出格式要求:
1.  你的回答必须是一个数字编号的列表。
2.  **【最重要】** 每一行指令都必须采用 `动作(参数) # 备注：状态描述` 的格式。备注必须以 `#` 开头，并用中文简要描述该动作执行后的世界状态或机器人的状态。
3.  在所有步骤的最后，必须另起一行，并严格按照 "Total Steps: [N]" 的格式报告总步数。
4.  除了动作列表和总步数报告，不要包含任何额外的解释。

# 这是一个完美的、带状态备注的端到端范例:
## 输入菜谱:
- 菜品名称: Lemon Chicken Breasts
- 菜谱文本: "Add to a Pot: Olive Oil [50ml], White Wine [10ml], Lemon Juice [10ml], Oregano, dried [5g], Thyme Twig [10g], Garlic [60g]. Fry for 60s. Take Chicken Breast [240g]. Season with: Salt [5g], Black Pepper [5g]. Cut Lemon [80g] into Pieces [16g]. Add to a Baking Tray: Mixture [70ml], Chicken Breast, Lemon. Fry for 90s. Transfer into a Deep Plate: Mixture [70ml], Chicken Breast, Lemon. Serve hot."

## 你的标准输出:
### 第一段：接取订单
1. goto(电脑) # 备注：机器人移动到电脑前
2. 点击(电脑, target="Lemon Chicken Breasts") # 备注：已在电脑上选择订单，任务开始
### 第二段：执行菜谱
3. goto(锅) # 备注：移动到锅前，准备添加调料
4. goto(橄榄油瓶) # 备注：移动到橄榄油瓶前
5. 拿起(橄榄油瓶) # 备注：橄榄油瓶在机械臂上
6. 水平移动到(锅) # 备注：橄榄油瓶位于锅的上方
7. 倾斜(橄榄油瓶) # 备注：正在向锅中倒入橄榄油
8. 放平(橄榄油瓶) # 备注：停止倾倒
9. 放下(橄榄油瓶) # 备注：橄榄油瓶已放回，机械臂空闲
10. goto(白葡萄酒瓶) # 备注：移动到白葡萄酒瓶前
11. 拿起(白葡萄酒瓶) # 备注：白葡萄酒瓶在机械臂上
12. 水平移动到(锅) # 备注：白葡萄酒瓶位于锅的上方
13. 倾斜(白葡萄酒瓶) # 备注：正在向锅中倒入白葡萄酒
14. 放平(白葡萄酒瓶) # 备注：停止倾倒
15. 放下(白葡萄酒瓶) # 备注：白葡萄酒瓶已放回，机械臂空闲
16. goto(柠檬汁瓶) # 备注：移动到柠檬汁瓶前
17. 拿起(柠檬汁瓶) # 备注：柠檬汁瓶在机械臂上
18. 水平移动到(锅) # 备注：柠檬汁瓶位于锅的上方
19. 倾斜(柠檬汁瓶) # 备注：正在向锅中倒入柠檬汁
20. 放平(柠檬汁瓶) # 备注：停止倾倒
21. 放下(柠檬汁瓶) # 备注：柠檬汁瓶已放回，机械臂空闲
22. goto(牛至容器) # 备注：移动到牛至容器前
23. 拿起(牛至容器) # 备注：牛至容器在机械臂上
24. 水平移动到(锅) # 备注：牛至容器位于锅的上方
25. 倾斜(牛至容器) # 备注：正在向锅中加入牛至
26. 放下(牛至容器) # 备注：牛至容器已放回，机械臂空闲
27. goto(百里香) # 备注：移动到百里香前
28. 拿起(百里香) # 备注：百里香在机械臂上
29. 水平移动到(锅) # 备注：百里香位于锅的上方
30. 放下(百里香, on=锅) # 备注：百里香已放入锅中，机械臂空闲
31. goto(大蒜) # 备注：移动到大蒜前
32. 拿起(大蒜) # 备注：大蒜在机械臂上
33. 水平移动到(锅) # 备注：大蒜位于锅的上方
34. 放下(大蒜, on=锅) # 备注：大蒜已放入锅中，机械臂空闲
35. 启动(炉灶) # 备注：炉灶已开启，锅正在加热
36. 等待(60秒) # 备注：正在翻炒调味汁
37. 关闭(炉灶) # 备注：炉灶已关闭，调味汁制作完成
38. goto(鸡胸肉) # 备注：移动到鸡胸肉前
39. 拿起(鸡胸肉) # 备注：鸡胸肉在机械臂上
40. goto(砧板) # 备注：移动到砧板前
41. 放下(鸡胸肉, on=砧板) # 备注：鸡胸肉已放在砧板上，机械臂空闲
42. goto(盐瓶) # 备注：移动到盐瓶前
43. 拿起(盐瓶) # 备注：盐瓶在机械臂上
44. 水平移动到(鸡胸肉) # 备注：盐瓶位于鸡胸肉上方
45. 倾斜(盐瓶) # 备注：正在给鸡胸肉撒盐
46. 放下(盐瓶) # 备注：盐瓶已放回，机械臂空闲
47. goto(黑胡椒瓶) # 备注：移动到黑胡椒瓶前
48. 拿起(黑胡椒瓶) # 备注：黑胡椒瓶在机械臂上
49. 水平移动到(鸡胸肉) # 备注：黑胡椒瓶位于鸡胸肉上方
50. 倾斜(黑胡椒瓶) # 备注：正在给鸡胸肉撒黑胡椒
51. 放下(黑胡椒瓶) # 备注：黑胡椒瓶已放回，机械臂空闲
52. goto(柠檬) # 备注：移动到柠檬前
53. 拿起(柠檬) # 备注：柠檬在机械臂上
54. goto(砧板) # 备注：移动到砧板前
55. 放下(柠檬, on=砧板) # 备注：柠檬已放在砧板上，机械臂空闲
56. goto(刀) # 备注：移动到刀前
57. 拿起(刀) # 备注：刀在机械臂上
58. 水平移动到(柠檬) # 备注：刀位于柠檬上方
59. 切割(柠檬, with=刀) # 备注：柠檬已被切成小块
60. 放下(刀) # 备注：刀已放回，机械臂空闲
61. goto(烤盘) # 备注：移动到烤盘前
62. goto(锅) # 备注：移动到装有调味汁的锅前
63. 拿起(锅) # 备注：锅在机械臂上
64. 水平移动到(烤盘) # 备注：锅位于烤盘上方
65. 倾斜(锅) # 备注：正在将调味汁倒入烤盘
66. 放下(锅) # 备注：锅已放回，机械臂空闲
67. goto(砧板) # 备注：移动到砧板前
68. 拿起(鸡胸肉) # 备注：拿起调味好的鸡胸肉
69. 水平移动到(烤盘) # 备注：鸡胸肉位于烤盘上方
70. 放下(鸡胸肉, on=烤盘) # 备注：鸡胸肉已放入烤盘
71. 拿起(柠檬块) # 备注：拿起切好的柠檬块
72. 水平移动到(烤盘) # 备注：柠檬块位于烤盘上方
73. 放下(柠檬块, on=烤盘) # 备注：柠檬块已放入烤盘，机械臂空闲
74. 拿起(烤盘) # 备注：拿起准备好烘烤的烤盘
75. goto(烤箱) # 备注：移动到烤箱前
76. 打开(烤箱) # 备注：烤箱门已打开
77. 放下(烤盘, on=烤箱) # 备注：烤盘已放入烤箱
78. 关闭(烤箱) # 备注：烤箱门已关闭
79. 启动(烤箱) # 备注：烤箱开始烘烤
80. 等待(90秒) # 备注：正在烘烤中
81. 关闭(烤箱) # 备注：烘烤完成
82. 打开(烤箱) # 备注：打开烤箱门准备取出
83. 拿起(烤盘) # 备注：烤熟的成品在机械臂上
84. 关闭(烤箱) # 备注：烤箱门已关闭
85. goto(操作台) # 备注：移动到操作台
86. 放下(烤盘) # 备注：烤盘已放在操作台上
### 第三段：装盘
87. goto(深口盘) # 备注：移动到干净的盘子前
88. goto(铲子) # 备注：移动到铲子前
89. 拿起(铲子) # 备注：铲子在机械臂上
90. goto(烤盘) # 备注：移动到烤好的成品前
91. 舀起(鸡胸肉, with=铲子) # 备注：用铲子舀起鸡胸肉
92. 水平移动到(深口盘) # 备注：将鸡胸肉移动到盘子上方
93. 放下(鸡胸肉, on=深口盘) # 备注：鸡胸肉已装盘
94. 舀起(柠檬块, with=铲子) # 备注：用铲子舀起柠檬块
95. 水平移动到(深口盘) # 备注：将柠檬块移动到盘子上方
96. 放下(柠檬块, on=深口盘) # 备注：柠檬块已装盘
97. 舀起(调味汁, with=铲子) # 备注：用铲子舀起剩余的调味汁
98. 水平移动到(深口盘) # 备注：将调味汁淋在菜上
99. 倾斜(铲子) # 备注：完成淋汁
100. 放下(铲子) # 备注：铲子已放回，机械臂空闲
### 第四段：提交菜品
101. goto(深口盘) # 备注：移动到装好盘的成品前
102. 拿起(深口盘) # 备注：成品在机械臂上
103. goto(传送台) # 备注：移动到提交菜品的传送台
104. 放下(深口盘, on=传送台) # 备注：菜品已提交，任务完成
Total Steps: 104
---
# 现在，请为以下新菜谱执行完全相同的任务:
"""

def call_llm_api(dish_name, recipe_text):
    if not recipe_text: return None, "Recipe text is empty."
    user_content = f"## 输入菜谱:\n- 菜品名称: {dish_name}\n- 菜谱文本: \"{recipe_text}\"\n\n## 你的标准输出:"
    try:
        response = client.chat.completions.create(
            model=GENERATOR_MODEL,
            messages=[{"role": "system", "content": PROMPT_TEMPLATE}, {"role": "user", "content": user_content}],
            temperature=0.2, max_tokens=8192
        )
        return response.choices[0].message.content.strip(), None
    except Exception as e:
        return None, str(e)

def parse_llm_output(text_output):
    if not text_output: return [], 0
    lines = text_output.strip().split('\n')
    steps, total_steps = [], 0
    for line in lines:
        line = line.strip()
        if line.startswith("###"): continue
        if line.lower().startswith("total steps:"):
            try: total_steps = int(line.split(':')[1].strip())
            except: total_steps = len(steps)
        elif line and line[0].isdigit():
            step_action_with_remark = '.'.join(line.split('.')[1:]).strip()
            if step_action_with_remark: steps.append(step_action_with_remark)
    if total_steps == 0 and steps: total_steps = len(steps)
    return steps, total_steps

def process_single_task_with_retries(task):
    """为单个任务封装API调用和重试逻辑"""
    final_error = f"Failed after all {MAX_RETRIES} retries."
    for attempt in range(MAX_RETRIES):
        llm_output, error = call_llm_api(task["dish_name"], task["recipe_text"])
        if error:
            final_error = error
            print(f"\n尝试 {attempt + 1}/{MAX_RETRIES} 处理 '{task['dish_name']}' 失败 (API Error): {error}。将在 {RETRY_DELAY} 秒后重试...")
            time.sleep(RETRY_DELAY)
            continue
        steps, total_steps_count = parse_llm_output(llm_output)
        if steps:
            return {"id": task['id'], "dish_name": task['dish_name'], "status": "success", "steps": steps, "total_steps": total_steps_count}
        else:
            final_error = "LLM returned empty or invalid steps."
            print(f"\n尝试 {attempt + 1}/{MAX_RETRIES} 处理 '{task['dish_name']}' 失败 (Invalid Output)。将在 {RETRY_DELAY} 秒后重试...")
            time.sleep(RETRY_DELAY)
    return {"id": task['id'], "dish_name": task['dish_name'], "status": "error", "error_message": final_error, "steps": [], "total_steps": 0}

def main():
    # --- 3. 核心执行逻辑 ---
    
    # 步骤 A: 加载所有需要的文件
    print("--- 正在加载文件 ---")
    try:
        with open(AGGREGATED_OUTPUT_PATH, 'r', encoding='utf-8') as f:
            aggregated_data = json.load(f)
        with open(INPUT_JSON_PATH, 'r', encoding='utf-8') as f:
            source_recipes_map = {r['id']: r for r in json.load(f)}
        with open(DECOMPOSED_OUTPUT_PATH, 'r', encoding='utf-8') as f:
            decomposed_results = json.load(f) if os.path.getsize(DECOMPOSED_OUTPUT_PATH) > 0 else []
    except FileNotFoundError as e:
        print(f"错误: 缺少必要文件 {e.filename}。请确保所有文件都在工作目录中。")
        return
    except Exception as e:
        print(f"加载文件时出错: {e}"); return

    # 步骤 B: 筛选出需要重新生成的菜品
    dishes_to_recheck = [
        dish for dish in aggregated_data 
        if dish.get("total_aggregated_steps", 0) < 85
    ]

    if not dishes_to_recheck:
        print("所有菜品的步数都大于等于85，无需重新生成。直接进入统计阶段。")
    else:
        print(f"\n--- 发现 {len(dishes_to_recheck)} 个菜品步数小于85，开始强制重新生成 ---")
        
        # 为了高效更新，创建一个分解结果的查找字典
        decomposed_map = {(item.get('id'), item.get('dish_name')): item for item in decomposed_results}

        for dish in tqdm(dishes_to_recheck, desc="复核并重新生成"):
            dish_id = dish.get('id')
            source_recipe = source_recipes_map.get(dish_id)
            if not source_recipe:
                print(f"警告: 在源文件 classic 1.json 中找不到 id={dish_id} 的菜品，跳过。")
                continue

            print(f"\n正在重新处理 ID: {dish_id}, 名称: {dish['dish_name']}")
            
            recipe_field = source_recipe.get('recipe', {})
            recipe_parts = recipe_field.keys() if isinstance(recipe_field, dict) else [source_recipe.get("dish_name")]
            
            for part_name in recipe_parts:
                recipe_text = recipe_field.get(part_name) if isinstance(recipe_field, dict) else recipe_field
                task = {"id": dish_id, "dish_name": part_name, "recipe_text": recipe_text}
                
                # 强制重新生成
                new_result = process_single_task_with_retries(task)
                
                # 更新或添加新结果到分解字典中
                decomposed_map[(dish_id, part_name)] = new_result
        
        # 将更新后的分解字典转换回列表并保存
        print("\n所有待复核菜品处理完毕，正在保存更新后的分解文件...")
        try:
            with open(DECOMPOSED_OUTPUT_PATH, 'w', encoding='utf-8') as f:
                json.dump(list(decomposed_map.values()), f, ensure_ascii=False, indent=4)
            print(f"'{DECOMPOSED_OUTPUT_PATH}' 已更新。")
        except IOError as e:
            print(f"错误: 无法写入分解文件。错误: {e}"); return
            
    # 步骤 C: 基于最新的分解数据，重新进行聚合
    print(f"\n--- 开始基于最新数据重新聚合所有 {len(source_recipes_map)} 个菜品 ---")
    
    # 重新加载更新后的分解文件
    with open(DECOMPOSED_OUTPUT_PATH, 'r', encoding='utf-8') as f:
        final_decomposed_results = json.load(f) if os.path.getsize(DECOMPOSED_OUTPUT_PATH) > 0 else []
    
    decomposed_lookup = {(item.get('id'), item.get('dish_name')): item for item in final_decomposed_results}
    
    final_aggregated_data = []
    for recipe_id, recipe_obj in tqdm(source_recipes_map.items(), desc="重新聚合进度"):
        final_dish_name = recipe_obj.get('dish_name')
        recipe_field = recipe_obj.get('recipe', {})
        total_steps, breakdown, action_flow = 0, [], []
        
        parts = recipe_field.keys() if isinstance(recipe_field, dict) else [final_dish_name]
        for part in parts:
            res = decomposed_lookup.get((recipe_id, part))
            if res and res.get('status') == 'success':
                s_count, s_list = res.get('total_steps', 0), res.get('steps', [])
                total_steps += s_count
                action_flow.extend(s_list)
                breakdown.append({"part_name": part, "status": "success", "steps_count": s_count, "steps_list": s_list})
            else:
                err_msg = res.get('error_message', 'Not found') if res else 'Not found'
                breakdown.append({"part_name": part, "status": "error", "steps_count": 0, "steps_list": [], "error_message": err_msg})
        
        final_aggregated_data.append({
            "id": recipe_id, "dish_name": final_dish_name, "original_recipe": recipe_field,
            "total_aggregated_steps": total_steps, "complete_action_flow": action_flow, "breakdown": breakdown
        })
        
    try:
        with open(AGGREGATED_OUTPUT_PATH, 'w', encoding='utf-8') as f:
            json.dump(final_aggregated_data, f, ensure_ascii=False, indent=4)
        print(f"重新聚合完成！最终报告已更新并保存到 '{AGGREGATED_OUTPUT_PATH}'。")
    except IOError as e:
        print(f"错误：无法写入最终聚合文件。错误: {e}"); return

    # 步骤 D: 进行最终的统计
    print("\n--- 开始进行最终数据统计 ---")
    all_steps = [dish.get("total_aggregated_steps", 0) for dish in final_aggregated_data]
    
    if all_steps:
        average_steps = np.mean(all_steps)
        median_steps = np.median(all_steps)
        
        print("\n================== 最终统计结果 ==================")
        print(f"菜品总数: {len(all_steps)}")
        print(f"平均动作步数 (Average): {average_steps:.2f}")
        print(f"动作步数中位数 (Median): {median_steps:.2f}")
        print("==================================================")
    else:
        print("没有可用于统计的数据。")

if __name__ == "__main__":
    main()
