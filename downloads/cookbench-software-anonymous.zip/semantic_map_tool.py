import pye57
import numpy as np
import os
import json
import open3d as o3d

class SemanticMapTool:
    def __init__(self, e57_file_path):
        print("[*] Initializing Semantic Map Tool...")
        # 数据的正确存储位置是 self.all_objects_data
        self.all_objects_data = self._load_semantic_map_data(e57_file_path)
        self.scene_boundary_vertices = self._calculate_scene_boundary()
        print(f"[*] Semantic Map loaded successfully. Found {len(self.all_objects_data)} objects.")
        if self.scene_boundary_vertices is not None:
            print("[*] Scene boundary calculated successfully.")

    def _parse_label(self, raw_label):
        label_info = {"raw": raw_label, "full_name_zh": "", "full_name_en": "", "parent": None, "child": None}
        parts = raw_label.split('/'); label_info["full_name_zh"] = parts[0]
        label_info["full_name_en"] = parts[1] if len(parts) > 1 else ""
        zh_parts = label_info["full_name_zh"].split('.')
        if len(zh_parts) > 1:
            label_info["parent"] = zh_parts[0]; label_info["child"] = '.'.join(zh_parts[1:])
        return label_info

    def _load_semantic_map_data(self, file_path):
        if not os.path.exists(file_path): raise FileNotFoundError(f"Semantic map file not found: {file_path}")
        e57 = pye57.E57(file_path)
        scan_count = e57.scan_count
        semantic_info_list = []
        for i in range(scan_count):
            header = e57.get_header(i)
            try: semantic_label = header["name"].value()
            except KeyError: semantic_label = header.guid.strip("{}")
            label_info = self._parse_label(semantic_label)
            data = e57.read_scan(i, ignore_missing_fields=True)
            if not all(k in data for k in ['cartesianX', 'cartesianY', 'cartesianZ']): continue
            points = np.vstack((data['cartesianX'], data['cartesianY'], data['cartesianZ'])).T
            if points.size == 0: continue
            pcd = o3d.geometry.PointCloud(); pcd.points = o3d.utility.Vector3dVector(points)
            semantic_info_list.append({
                "label_info": label_info,
                "center": pcd.get_center().tolist(),
                "size": pcd.get_axis_aligned_bounding_box().get_extent().tolist(),
                "aabb": pcd.get_axis_aligned_bounding_box()
            })
        return semantic_info_list

    def _calculate_scene_boundary(self):
        wall1_data = next((obj for obj in self.all_objects_data if obj['label_info']['full_name_zh'] == '墙.1'), None)
        wall2_data = next((obj for obj in self.all_objects_data if obj['label_info']['full_name_zh'] == '墙.2'), None)
        if not wall1_data or not wall2_data:
            print("[!] Warning: Could not find '墙.1' and/or '墙.2' to calculate precise boundary.")
            return None
        min1, max1 = wall1_data['aabb'].min_bound, wall1_data['aabb'].max_bound
        min2, max2 = wall2_data['aabb'].min_bound, wall2_data['aabb'].max_bound
        z_min = min(min1[2], min2[2])
        z_max = max(max1[2], max2[2])
        xy_vertices = [(max2[0], max2[1]), (max2[0], min1[1]), (min1[0], min1[1]),
                       (min1[0], max1[1]), (min2[0], max1[1]), (min2[0], max2[1])]
        vertices_3d = []
        for x, y in xy_vertices: vertices_3d.append([x, y, z_min])
        for x, y in xy_vertices: vertices_3d.append([x, y, z_max])
        return np.array(vertices_3d).tolist()

    # 【关键修正 1】修正函数定义，它只需要 query_label 作为参数
    def find_objects_by_label_fuzzy(self, query_label):
        """模糊匹配查找物体，返回所有匹配项的列表。"""
        matches = []
        query_lower = query_label.lower()
        added_labels = set()
        
        # 【关键修正 2】使用正确的内部数据源 self.all_objects_data
        # 优先完全匹配
        for obj in self.all_objects_data:
            if query_label == obj['label_info']['full_name_zh'] or query_label == obj['label_info']['full_name_en']:
                if obj['label_info']['raw'] not in added_labels:
                    matches.append(obj)
                    added_labels.add(obj['label_info']['raw'])

        # 回退到子字符串匹配
        for obj in self.all_objects_data:
            if obj['label_info']['raw'] in added_labels: continue
            if query_lower in obj['label_info']['full_name_zh'].lower() or \
               (obj['label_info']['full_name_en'] and query_lower in obj['label_info']['full_name_en'].lower()):
                matches.append(obj)
                added_labels.add(obj['label_info']['raw'])
                
        return matches

    def query_object_relationships(self, target_label, k=3):
        """查询一个物体的完整空间和层级关系，并返回详细信息。"""
        # 这里的调用现在是完全正确的，因为它匹配了上面修正后的函数定义
        matches = self.find_objects_by_label_fuzzy(target_label)
        if not matches: return []

        results = []
        for target_obj in matches:
            target_pos = np.array(target_obj['center'])
            target_info = target_obj['label_info']
            parent_obj, siblings, parts, other_objects = None, [], [], []

            if target_info['parent']:
                for obj in self.all_objects_data:
                    if obj['label_info']['full_name_zh'] == target_info['parent']: parent_obj = obj
                    elif obj['label_info']['parent'] == target_info['parent'] and obj['label_info']['raw'] != target_info['raw']: siblings.append(obj)
            
            for obj in self.all_objects_data:
                if obj['label_info']['raw'] == target_info['raw']: continue
                if obj['label_info']['parent'] == target_info['full_name_zh']: parts.append(obj)
                elif obj['label_info']['parent'] != target_info['parent']:
                    obj['distance_to_target'] = np.linalg.norm(np.array(obj['center']) - target_pos)
                    other_objects.append(obj)
            
            nearest_k = sorted(other_objects, key=lambda x: x['distance_to_target'])[:k]
            
            def format_obj(obj):
                if not obj: return None
                return {"label": obj['label_info']['full_name_zh'], "center": obj['center'], "size": obj['size']}

            results.append({
                "target": format_obj(target_obj),
                "parent": format_obj(parent_obj),
                "siblings": [format_obj(s) for s in siblings],
                "parts": [format_obj(p) for p in parts],
                "nearby": [{"label": n['label_info']['full_name_zh'], "center": n['center'], "size": n['size'], 
                            "distance": n['distance_to_target']} for n in nearest_k]
            })
        return results