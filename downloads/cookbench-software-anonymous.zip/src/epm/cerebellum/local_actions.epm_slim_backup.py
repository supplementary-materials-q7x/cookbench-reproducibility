from __future__ import annotations

import inspect
import sys
import time
from typing import Literal, Optional

from epm.cerebellum.raw_input_controller import RawInputController
from epm.vision.screen_capture import get_window_rect


_io = RawInputController()


# ----------------------------
# Internal helpers (not exposed)
# ----------------------------
def _click_mouse(button: Literal["left", "right", "middle"] = "left") -> None:
    _io.click(button)


def _smooth_move_to_position(
    x: int,
    y: int,
    *,
    click: Optional[Literal["left", "right", "middle"]] = None,
    window_title: str = "CookingSimulator",
    move_delay_s: float = 0.08,
) -> None:
    rect = get_window_rect(window_title)
    screen_x = rect.left + int(x)
    screen_y = rect.top + int(y)
    _io.mouse_move_absolute(screen_x, screen_y)
    time.sleep(float(move_delay_s))
    if click:
        _click_mouse(click)


def _key_down(key: str) -> None:
    _io.key_down(key)


def _key_up(key: str) -> None:
    _io.key_up(key)


# ----------------------------
# Common skills / semantic actions
# ----------------------------

def noop() -> None:
    """Do nothing."""
    return None

# [ALFRED/Navigate(移动)]
def move_forward(duration: float = 0.3) -> None:
    """Move forward for a short duration."""
    _key_down("w")
    time.sleep(float(duration))
    _key_up("w")


def move_backward(duration: float = 0.3) -> None:
    """Move backward for a short duration."""
    _key_down("s")
    time.sleep(float(duration))
    _key_up("s")


def move_left(duration: float = 0.3) -> None:
    """Strafe left for a short duration."""
    _key_down("a")
    time.sleep(float(duration))
    _key_up("a")


def move_right(duration: float = 0.3) -> None:
    """Strafe right for a short duration."""
    _key_down("d")
    time.sleep(float(duration))
    _key_up("d")


def move_forward_left(duration: float = 0.3) -> None:
    """Move forward-left (W+A) for a short duration."""
    _key_down("w")
    _key_down("a")
    time.sleep(float(duration))
    _key_up("w")
    _key_up("a")


def move_forward_right(duration: float = 0.3) -> None:
    """Move forward-right (W+D) for a short duration."""
    _key_down("w")
    _key_down("d")
    time.sleep(float(duration))
    _key_up("w")
    _key_up("d")


def move_backward_left(duration: float = 0.3) -> None:
    """Move backward-left (S+A) for a short duration."""
    _key_down("s")
    _key_down("a")
    time.sleep(float(duration))
    _key_up("s")
    _key_up("a")


def move_backward_right(duration: float = 0.3) -> None:
    """Move backward-right (S+D) for a short duration."""
    _key_down("s")
    _key_down("d")
    time.sleep(float(duration))
    _key_up("s")
    _key_up("d")


# [ALFRED/OpenObject-OpenDoor(开门)]
def Open_the_door_of_the_oven(x: int, y: int, key: Literal["left", "right", "middle"] = "left") -> None:
    """Open the oven door (click at given window-relative coordinates)."""
    _smooth_move_to_position(x, y, click=key)


def Open_left_refrigerator_door(x: int, y: int, key: Literal["left", "right", "middle"] = "left") -> None:
    """Open the left refrigerator door (click at given window-relative coordinates)."""
    _smooth_move_to_position(x, y, click=key)


def Open_right_refrigerator_door(x: int, y: int, key: Literal["left", "right", "middle"] = "left") -> None:
    """Open the right refrigerator door (click at given window-relative coordinates)."""
    _smooth_move_to_position(x, y, click=key)


def Open_Microwave_oven_door(x: int, y: int, key: Literal["left", "right", "middle"] = "left") -> None:
    """Open the microwave door (click at given window-relative coordinates)."""
    _smooth_move_to_position(x, y, click=key)


# [ALFRED/CloseObject-CloseDoor(关门)]
def Close_the_door_of_the_oven(x: int, y: int, key: Literal["left", "right", "middle"] = "left") -> None:
    """Close the oven door (click at given window-relative coordinates)."""
    _smooth_move_to_position(x, y, click=key)


def Close_left_refrigerator_door(x: int, y: int, key: Literal["left", "right", "middle"] = "left") -> None:
    """Close the left refrigerator door (click at given window-relative coordinates)."""
    _smooth_move_to_position(x, y, click=key)


def Close_right_refrigerator_door(x: int, y: int, key: Literal["left", "right", "middle"] = "left") -> None:
    """Close the right refrigerator door (click at given window-relative coordinates)."""
    _smooth_move_to_position(x, y, click=key)


def Close_Microwave_oven_door(x: int, y: int, key: Literal["left", "right", "middle"] = "left") -> None:
    """Close the microwave door (click at given window-relative coordinates)."""
    _smooth_move_to_position(x, y, click=key)


# [ALFRED/ToggleOn(打开开关/启动设备)]
def turn_on_switch(key: Literal["left", "right", "middle"] = "left") -> None:
    """Toggle on a stove switch at the current cursor location."""
    _click_mouse(key)


# [ALFRED/ToggleOff(关闭开关/停止设备)]
def turn_off_switch(key: Literal["left", "right", "middle"] = "left") -> None:
    """Toggle off a stove switch at the current cursor location."""
    _click_mouse(key)


# [ALFRED/PickupObject(拿起)] / [ALFRED/PutObject(放下)]
def pick_up(key: Literal["left", "right", "middle"] = "left") -> None:
    """Pick up the object at current cursor."""
    _click_mouse(key)


def put_down(key: Literal["left", "right", "middle"] = "left") -> None:
    """Put down / drop the held object at current cursor."""
    _click_mouse(key)


# [ALFRED/SliceObject(切割)]
def Enter_cutting_mode(x: int, y: int, key: Literal["left", "right", "middle"] = "left") -> None:
    """Enter cutting mode by clicking at the target position."""
    _smooth_move_to_position(x, y, click=key)


def cut_down(key: Literal["left", "right", "middle"] = "left") -> None:
    """Perform a cut action in cutting mode."""
    _click_mouse(key)


def Escape_cutting_mode(key: Literal["left", "right", "middle"] = "right") -> None:
    """Exit cutting mode."""
    _click_mouse(key)


def Cutting_raw_materials(x: int, y: int, key: Literal["left", "right", "middle"] = "left") -> None:
    """Cut raw materials at the target position."""
    _smooth_move_to_position(x, y, click=key)


def _is_action_function(obj) -> bool:
    return inspect.isfunction(obj) and obj.__module__ == __name__ and not obj.__name__.startswith("_")


ACTION_DISPATCHER = {name: func for name, func in inspect.getmembers(sys.modules[__name__], _is_action_function)}
