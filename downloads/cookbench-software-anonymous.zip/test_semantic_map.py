# test_semantic_map_v2.py
import pye57
import numpy as np
import open3d as o3d
import os
import random

# --- 配置 ---
E57_FILE_PATH = "./Semantic_map-20250712.e57" 

def advanced_parse_and_visualize_e57(file_path):
    """
    高级解析器：遍历e57文件中的所有点云，读取语义标签、计算中心点和边界框，并进行可视化。
    """
    print(f"[*] 正在尝试解析文件: {file_path}")

    if not os.path.exists(file_path):
        print(f"[!] 错误: 文件未找到 at '{file_path}'")
        return

    try:
        e57 = pye57.E57(file_path)
        
        scan_count = e57.scan_count
        print(f"[*] 文件中包含 {scan_count} 个子点云。")

        all_pcds = [] 
        semantic_info_list = [] # 用于存储所有子点云的结构化信息
        color_map = {}
        
        print("\n--- 开始解析所有子点云 ---")
        for i in range(scan_count):
            header = e57.get_header(i)
            try:
                semantic_label = header["name"].value()       # 首选：E57 文件里真正写入的扫描名称
            except KeyError:
                semantic_label = header.guid.strip("{}")      # 回退：用 GUID 充当标签

            
            print(f"  -> 正在处理第 {i+1}/{scan_count} 个点云: '{semantic_label}'")
            
            data = e57.read_scan(i, ignore_missing_fields=True)
            
            if not all(k in data for k in ['cartesianX', 'cartesianY', 'cartesianZ']):
                print(f"     [警告] 点云 '{semantic_label}' 缺少坐标数据，已跳过。")
                continue

            points = np.vstack((data['cartesianX'], data['cartesianY'], data['cartesianZ'])).T
            
            pcd = o3d.geometry.PointCloud()
            pcd.points = o3d.utility.Vector3dVector(points)

            # 计算中心点和边界框
            center = pcd.get_center()
            aabb = pcd.get_axis_aligned_bounding_box()
            aabb_size = aabb.get_extent()

            # 存储结构化信息
            semantic_info_list.append({
                "label": semantic_label,
                "center_position": center.tolist(),
                "bounding_box_size": aabb_size.tolist()
            })

            # 为可视化分配颜色
            if semantic_label not in color_map:
                color = [random.random(), random.random(), random.random()]
                color_map[semantic_label] = color
            
            pcd.paint_uniform_color(color_map[semantic_label])
            all_pcds.append(pcd)

        print("--------------------------\n")

        if not all_pcds:
            print("[!] 未能从文件中成功解析任何点云。")
            return
            
        # 在可视化前，打印所有提取到的信息
        print("--- 提取的语义地图信息 ---")
        for info in semantic_info_list:
            print(f"- 标签: {info['label']}")
            print(f"  中心点 (X,Y,Z): {[round(c, 3) for c in info['center_position']]}")
            print(f"  尺寸 (W,H,D): {[round(s, 3) for s in info['bounding_box_size']]}")
            print("-" * 20)
        print("--------------------------\n")

        # 打印图例
        print("--- 可视化图例 (颜色: 语义标签) ---")
        for label, color in color_map.items():
            print(f"  - Color {str(np.round(color, 2))}: {label}")
        print("-------------------------------------\n")

        # 将所有点云一起可视化
        print("[*] 正在启动3D可视化窗口... (您可以旋转和缩放视图)")
        
        vis = o3d.visualization.Visualizer()
        vis.create_window(window_name="完整语义地图预览 (按标签着色)")
        for pcd in all_pcds:
            vis.add_geometry(pcd)
        vis.run()
        vis.destroy_window()
        
        print("[*] 可视化窗口已关闭。")

    except Exception as e:
        print(f"[!] 处理.e57文件时发生严重错误: {e}")

if __name__ == "__main__":
    advanced_parse_and_visualize_e57(E57_FILE_PATH)