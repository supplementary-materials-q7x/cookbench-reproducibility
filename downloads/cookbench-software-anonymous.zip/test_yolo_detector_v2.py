# test_yolo_detector_v2.py
import tkinter as tk
import time
import json
import sys
import os
# 依赖我们项目中的其他文件
# 确保此脚本与 local_detector.py, local_actions.py, config.json 在同一目录下
current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
sys.path.append(parent_dir)

from local_detector import LocalDetector
import local_actions 

class DetectionOverlay:
    """
    创建一个透明的、总在最前的窗口，用于在游戏上绘制检测结果。
    """
    def __init__(self, game_window_rect):
        self.root = tk.Tk()
        self.root.geometry(f"{game_window_rect['width']}x{game_window_rect['height']}+{game_window_rect['left']}+{game_window_rect['top']}")
        self.root.overrideredirect(True)
        self.root.attributes("-topmost", True)
        transparent_color = 'gray90'
        self.root.attributes("-transparentcolor", transparent_color)
        self.canvas = tk.Canvas(self.root, bg=transparent_color, highlightthickness=0)
        self.canvas.pack(fill=tk.BOTH, expand=True)
        self.is_running = True

        # 绑定'q'键来关闭窗口
        self.root.bind('<q>', self.quit)

    def quit(self, event=None):
        """关闭窗口的函数。"""
        self.is_running = False
        self.root.destroy()

    def update_canvas(self, detections, target_object=None):
        """在透明画布上绘制检测结果。"""
        self.canvas.delete("all") # 清除旧的绘制内容
        
        if not detections: return

        for det in detections:
            label, conf, box, center = det['label'], det['confidence'], det['bounding_box'], det['center']
            x1, y1, x2, y2 = box
            
            self.canvas.create_rectangle(x1, y1, x2, y2, outline="lime", width=3)
            text = f"{label}: {conf:.2f}"
            text_id = self.canvas.create_text(x1, y1 - 12, text=text, fill="white", font=("Arial", 12, "bold"), anchor="sw")
            bbox = self.canvas.bbox(text_id)
            self.canvas.create_rectangle(bbox, fill="green", outline="green")
            self.canvas.tag_raise(text_id)

            if target_object and label == target_object:
                radius = 5
                self.canvas.create_oval(center['x'] - radius, center['y'] - radius, center['x'] + radius, center['y'] + radius, fill="red", outline="red")
        
        # 刷新画布
        self.root.update_idletasks()
        self.root.update()

def run_realtime_yolo_test(target_for_click=None):
    """
    主测试函数：激活游戏，实时截图、检测，并在游戏窗口上显示结果。
    """
    print("--- YOLO-World 本地检测与实时覆盖测试 ---")
    
    # 1. 加载配置
    try:
        with open('config.json', 'r', encoding='utf-8') as f:
            cfg = json.load(f)
        yolo_path = cfg.get('local_model_config', {}).get('yolo_world_path')
        if not yolo_path: print("[!] 错误: 未在config.json中配置 'yolo_world_path'。"); return
    except Exception as e:
        print(f"[!] 加载配置文件时出错: {e}"); return

    # 2. 初始化检测器
    detector = LocalDetector(yolo_path)
    if not detector.model: print("[!] 检测器初始化失败，测试终止。"); return

    # 3. 激活并获取游戏窗口
    try:
        print("[*] 正在激活 'CookingSimulator' 窗口...")
        local_actions._activate_window()
        game_rect = local_actions._get_window_rect()
        print(f"[*] 窗口已激活，位置: {game_rect}")
    except Exception as e:
        print(f"[!] 激活或获取窗口失败: {e}"); return

    # 4. 创建覆盖窗口
    overlay = DetectionOverlay(game_rect)
    
    # 5. 定义要测试的物体类别
    objects_to_find = ["pot", "knife", "cutting board", "plate", "lemon", "tomato", "onion", "chicken"]
    print(f"[*] 计划检测的物体: {objects_to_find}")
    print("\n[*] ======= 实时监测已启动！请将鼠标移动到覆盖窗口上，按 'q' 键退出。=======")

    # 6. 主循环：实时检测与绘制
    while overlay.is_running:
        try:
            # 截图
            screenshot_pil = local_actions._capture_screenshot_mss(region=game_rect)
            # 检测
            detections = detector.find_objects(screenshot_pil, objects_to_find)
            # 更新覆盖层
            overlay.update_canvas(detections, target_for_click)
            # 控制帧率，避免过度占用CPU
            time.sleep(0.1)
        except tk.TclError:
            print("\n[*] 覆盖窗口已关闭。")
            break
        except Exception as e:
            print(f"\n[!] 循环中发生错误: {e}")
            break
            
    print("[*] 测试完成。")

if __name__ == "__main__":
    target_object_to_highlight = "pot"
    run_realtime_yolo_test(target_for_click=target_object_to_highlight)
