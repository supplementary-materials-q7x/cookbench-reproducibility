import time
import os
import json
from typing import List, Dict, Tuple, Optional, Union, Any
from PIL import Image

from vlm_navigator import VLMNavigator
from ai_connector import AIConnector
from local_actions import (
    move_forward, move_backward, move_left, move_right,
    look_up, look_down, look_left, look_right,
    _capture_screenshot_mss, _activate_window
)

class VLMAgent:
    """
    整合VLM导航和LLM任务规划的代理系统
    """
    def __init__(self, 
                 yolo_model_path: str = "yolov8l-worldv2.pt",
                 config_path: str = "config.json"):
        """
        初始化VLM代理
        
        Args:
            yolo_model_path: YOLO-World模型路径
            config_path: 配置文件路径
        """
        self.navigator = VLMNavigator(yolo_model_path)
        self.ai_connector = AIConnector(config_path)
        self.current_task = None
        self.task_status = "idle"  # idle, navigating, executing
        self.navigation_target = None
        self.execution_plan = []
        self.execution_step = 0
        
    def set_task(self, task_description: str) -> None:
        """
        设置当前任务
        
        Args:
            task_description: 任务描述
        """
        self.current_task = task_description
        self.task_status = "idle"
        self.navigation_target = None
        self.execution_plan = []
        self.execution_step = 0
        print(f"[*] 设置新任务: {task_description}")
        
    def analyze_task(self) -> Dict[str, Any]:
        """
        分析当前任务，确定导航目标和执行计划
        
        Returns:
            任务分析结果，包含导航目标和执行计划
        """
        if not self.current_task:
            print("[!] 没有设置任务，无法分析")
            return {}
            
        # 捕获当前场景
        scene_image = self.navigator.capture_current_view()
        
        # 使用AI连接器分析任务
        task_analysis = self.ai_connector.recognize_intent(
            self.current_task, 
            scene_image
        )
        
        # 提取导航目标和执行计划
        if "navigation_target" in task_analysis:
            self.navigation_target = task_analysis["navigation_target"]
        
        if "execution_plan" in task_analysis:
            self.execution_plan = task_analysis["execution_plan"]
            
        return task_analysis
        
    def execute_task(self) -> bool:
        """
        执行当前任务，包括导航和操作
        
        Returns:
            如果任务成功完成则返回True，否则返回False
        """
        if not self.current_task:
            print("[!] 没有设置任务，无法执行")
            return False
            
        # 如果还没有分析任务，先进行分析
        if not self.navigation_target and not self.execution_plan:
            self.analyze_task()
            
        # 如果有导航目标，先进行导航
        if self.navigation_target:
            print(f"[*] 开始导航到: {self.navigation_target}")
            self.task_status = "navigating"
            
            # 使用VLM导航器导航到目标
            navigation_success = self.navigator.search_and_approach(self.navigation_target)
            
            if not navigation_success:
                print(f"[!] 导航失败: 无法找到 {self.navigation_target}")
                return False
                
            print(f"[*] 导航成功: 已到达 {self.navigation_target}")
            
        # 执行操作计划
        self.task_status = "executing"
        
        # 捕获当前场景
        scene_image = self.navigator.capture_current_view()
        
        # 使用AI连接器执行任务
        execution_success = self.ai_connector.execute_task(
            self.current_task,
            scene_image,
            self.execution_plan
        )
        
        self.task_status = "idle"
        return execution_success
        
    def navigate_and_execute(self, task_description: str) -> bool:
        """
        设置任务并执行，包括导航和操作
        
        Args:
            task_description: 任务描述
            
        Returns:
            如果任务成功完成则返回True，否则返回False
        """
        self.set_task(task_description)
        return self.execute_task()
        
    def explore_environment(self) -> Dict[str, List[Dict]]:
        """
        探索环境，获取周围物体的信息
        
        Returns:
            探索到的物体信息
        """
        print("[*] 开始探索环境...")
        return self.navigator.explore_area(steps=5)
        
    def get_navigation_actions(self) -> List[str]:
        """
        获取可用的导航动作列表
        
        Returns:
            导航动作列表
        """
        return [
            "move_forward", "move_backward", "move_left", "move_right",
            "look_up", "look_down", "look_left", "look_right"
        ]
        
    def execute_navigation_action(self, action: str) -> bool:
        """
        执行单个导航动作
        
        Args:
            action: 导航动作名称
            
        Returns:
            如果动作执行成功则返回True，否则返回False
        """
        action_map = {
            "move_forward": move_forward,
            "move_backward": move_backward,
            "move_left": move_left,
            "move_right": move_right,
            "look_up": look_up,
            "look_down": look_down,
            "look_left": look_left,
            "look_right": look_right
        }
        
        if action in action_map:
            try:
                action_map[action]()
                return True
            except Exception as e:
                print(f"[!] 执行导航动作时出错: {e}")
                return False
        else:
            print(f"[!] 未知的导航动作: {action}")
            return False