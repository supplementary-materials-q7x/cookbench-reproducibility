import time
import numpy as np
from PIL import Image
from typing import List, Dict, Tuple, Optional, Union
import mss

from local_detector import LocalDetector
from local_actions import (
    move_forward, move_backward, move_left, move_right,
    look_up, look_down, look_left, look_right,
    _capture_screenshot_mss, _activate_window
)

class VLMNavigator:
    """
    使用VLM（视觉语言模型）进行环境感知和导航的类
    """
    def __init__(self, yolo_model_path: str = "yolov8l-worldv2.pt"):
        """
        初始化VLM导航器
        
        Args:
            yolo_model_path: YOLO-World模型路径
        """
        self.detector = LocalDetector(yolo_model_path)
        self.current_screenshot = None
        self.last_seen_objects = []
        self.navigation_history = []
        self.target_object = None
        self.search_attempts = 0
        self.max_search_attempts = 12  # 最大搜索尝试次数
        self.rotation_complete = False
        
    def capture_current_view(self) -> Image.Image:
        """捕获当前屏幕视图"""
        try:
            _activate_window()
            self.current_screenshot = _capture_screenshot_mss()
            return self.current_screenshot
        except Exception as e:
            print(f"[!] 捕获屏幕时出错: {e}")
            return None
    
    def detect_objects(self, queries: List[str]) -> List[Dict]:
        """
        检测当前视图中的物体
        
        Args:
            queries: 要检测的物体名称列表
            
        Returns:
            检测到的物体列表，每个物体包含标签、置信度、边界框和中心点
        """
        if self.current_screenshot is None:
            self.capture_current_view()
            
        if self.current_screenshot:
            self.last_seen_objects = self.detector.find_objects(self.current_screenshot, queries)
            return self.last_seen_objects
        return []
    
    def is_object_visible(self, object_name: str) -> bool:
        """
        检查指定物体是否可见
        
        Args:
            object_name: 物体名称
            
        Returns:
            如果物体可见则返回True，否则返回False
        """
        for obj in self.last_seen_objects:
            if obj["label"].lower() == object_name.lower() and obj["confidence"] > 0.4:
                return True
        return False
    
    def get_object_position(self, object_name: str) -> Optional[Dict]:
        """
        获取指定物体的位置信息
        
        Args:
            object_name: 物体名称
            
        Returns:
            物体的位置信息，包括中心点坐标
        """
        for obj in self.last_seen_objects:
            if obj["label"].lower() == object_name.lower() and obj["confidence"] > 0.4:
                return obj
        return None
    
    def navigate_to_object(self, target_object: str, object_queries: List[str] = None) -> bool:
        """
        导航到指定物体
        
        Args:
            target_object: 目标物体名称
            object_queries: 要检测的物体名称列表，如果为None则使用target_object
            
        Returns:
            如果成功导航到物体则返回True，否则返回False
        """
        self.target_object = target_object
        self.search_attempts = 0
        self.rotation_complete = False
        
        if object_queries is None:
            object_queries = [target_object]
            
        # 首先检查当前视图中是否有目标物体
        self.capture_current_view()
        self.detect_objects(object_queries)
        
        while self.search_attempts < self.max_search_attempts:
            # 检查是否找到目标物体
            if self.is_object_visible(target_object):
                print(f"[*] 找到目标物体: {target_object}")
                return self._approach_visible_object(target_object)
            
            # 如果没找到，执行搜索策略
            if not self.rotation_complete:
                # 旋转搜索
                print(f"[*] 正在搜索物体: {target_object}，尝试 #{self.search_attempts+1}")
                look_right()  # 向右转动视角
                self.search_attempts += 1
                
                # 完成一圈旋转后
                if self.search_attempts % 8 == 0:
                    self.rotation_complete = True
            else:
                # 如果旋转一圈后仍未找到，尝试移动后再搜索
                print(f"[*] 未找到物体，尝试移动后继续搜索")
                move_forward()  # 向前移动
                self.rotation_complete = False  # 重置旋转状态
            
            # 捕获新的视图并检测
            self.capture_current_view()
            self.detect_objects(object_queries)
            
        print(f"[!] 无法找到目标物体: {target_object}，已达到最大尝试次数")
        return False
    
    def _approach_visible_object(self, object_name: str) -> bool:
        """
        接近视野中可见的物体
        
        Args:
            object_name: 物体名称
            
        Returns:
            如果成功接近物体则返回True，否则返回False
        """
        obj_pos = self.get_object_position(object_name)
        if not obj_pos:
            return False
            
        # 获取屏幕中心和物体中心
        screen_width = self.current_screenshot.width
        screen_height = self.current_screenshot.height
        screen_center_x = screen_width // 2
        screen_center_y = screen_height // 2
        
        obj_center_x = obj_pos["center"]["x"]
        obj_center_y = obj_pos["center"]["y"]
        
        # 计算物体与屏幕中心的距离
        distance_x = obj_center_x - screen_center_x
        distance_y = obj_center_y - screen_center_y
        
        # 如果物体不在屏幕中心附近，调整视角
        if abs(distance_x) > 50:
            if distance_x > 0:
                look_right(pixels=min(distance_x, 150))
            else:
                look_left(pixels=min(abs(distance_x), 150))
                
        if abs(distance_y) > 50:
            if distance_y > 0:
                look_down(pixels=min(distance_y, 100))
            else:
                look_up(pixels=min(abs(distance_y), 100))
        
        # 向前移动接近物体
        move_forward()
        
        # 再次检查物体是否可见且更近
        self.capture_current_view()
        self.detect_objects([object_name])
        
        new_obj_pos = self.get_object_position(object_name)
        if new_obj_pos:
            # 检查物体是否更近（边界框更大）
            old_box = obj_pos["bounding_box"]
            new_box = new_obj_pos["bounding_box"]
            
            old_area = (old_box[2] - old_box[0]) * (old_box[3] - old_box[1])
            new_area = (new_box[2] - new_box[0]) * (new_box[3] - new_box[1])
            
            if new_area > old_area:
                print(f"[*] 成功接近物体: {object_name}")
                return True
                
        # 如果物体仍然可见但没有变大，可能需要继续接近
        if self.is_object_visible(object_name):
            move_forward()
            return True
            
        return False
    
    def scan_environment(self, object_queries: List[str]) -> Dict[str, List[Dict]]:
        """
        扫描环境中的所有指定物体
        
        Args:
            object_queries: 要检测的物体名称列表
            
        Returns:
            检测到的所有物体的字典，按物体名称分组
        """
        self.capture_current_view()
        objects = self.detect_objects(object_queries)
        
        # 执行360度扫描
        results = {obj["label"]: [] for obj in objects}
        for obj in objects:
            results[obj["label"]].append(obj)
            
        for _ in range(8):  # 旋转一周
            look_right()
            self.capture_current_view()
            objects = self.detect_objects(object_queries)
            
            for obj in objects:
                if obj["label"] not in results:
                    results[obj["label"]] = []
                results[obj["label"]].append(obj)
                
        return results
    
    def search_and_approach(self, target_object: str, additional_objects: List[str] = None) -> bool:
        """
        搜索并接近目标物体，同时也检测其他相关物体
        
        Args:
            target_object: 目标物体名称
            additional_objects: 额外要检测的物体名称列表
            
        Returns:
            如果成功找到并接近目标物体则返回True，否则返回False
        """
        queries = [target_object]
        if additional_objects:
            queries.extend(additional_objects)
            
        return self.navigate_to_object(target_object, queries)
    
    def explore_area(self, steps: int = 3) -> Dict[str, List[Dict]]:
        """
        探索周围区域，记录看到的所有物体
        
        Args:
            steps: 向前移动的步数
            
        Returns:
            探索过程中看到的所有物体
        """
        common_objects = ["table", "counter", "stove", "refrigerator", "sink", 
                         "cabinet", "shelf", "oven", "microwave", "pot", "pan", 
                         "knife", "cutting board", "plate", "bowl", "cup", "glass",
                         "food", "ingredient", "spice", "utensil", "tool"]
        
        all_objects = {}
        
        # 首先在当前位置进行360度扫描
        current_objects = self.scan_environment(common_objects)
        for label, objs in current_objects.items():
            if label not in all_objects:
                all_objects[label] = []
            all_objects[label].extend(objs)
        
        # 然后向前移动几步，每步都进行扫描
        for _ in range(steps):
            move_forward()
            current_objects = self.scan_environment(common_objects)
            
            for label, objs in current_objects.items():
                if label not in all_objects:
                    all_objects[label] = []
                all_objects[label].extend(objs)
        
        return all_objects